<?php
class form_comprascotaresposta_form extends form_comprascotaresposta_apl
{
function Form_Init()
{
   global $sc_seq_vert, $nm_apl_dependente, $opcao_botoes, $nm_url_saida; 
?>
<?php

if (!isset($this->NM_ajax_info['param']['buffer_output']) || !$this->NM_ajax_info['param']['buffer_output'])
{
    $sOBContents = ob_get_contents();
    ob_end_clean();
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
            "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">

<html<?php echo $_SESSION['scriptcase']['reg_conf']['html_dir'] ?>>
<HEAD>
 <TITLE><?php if ('novo' == $this->nmgp_opcao) { echo strip_tags("" . $this->Ini->Nm_lang['lang_othr_frmi_titl'] . " - comprascotaresposta"); } else { echo strip_tags("" . $this->Ini->Nm_lang['lang_othr_frmu_titl'] . " - comprascotaresposta"); } ?></TITLE>
 <META http-equiv="Content-Type" content="text/html; charset=<?php echo $_SESSION['scriptcase']['charset_html'] ?>" />
 <META http-equiv="Expires" content="Fri, Jan 01 1900 00:00:00 GMT"/>
 <META http-equiv="Last-Modified" content="<?php echo gmdate("D, d M Y H:i:s"); ?> GMT"/>
 <META http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate"/>
 <META http-equiv="Cache-Control" content="post-check=0, pre-check=0"/>
 <META http-equiv="Pragma" content="no-cache"/>
 <SCRIPT language="javascript" src="<?php echo $this->Ini->url_lib_js; ?>dynifs.js"></SCRIPT>
 <link rel="stylesheet" href="<?php echo $this->Ini->path_prod ?>/third/jquery_plugin/thickbox/thickbox.css" type="text/css" media="screen" />
 <SCRIPT type="text/javascript">
  var sc_pathToTB = '<?php echo $this->Ini->path_prod ?>/third/jquery_plugin/thickbox/';
  var sc_blockCol = '<?php echo $this->Ini->Block_img_col; ?>';
  var sc_blockExp = '<?php echo $this->Ini->Block_img_exp; ?>';
  var sc_ajaxBg = '<?php echo $this->Ini->Color_bg_ajax; ?>';
  var sc_ajaxBordC = '<?php echo $this->Ini->Border_c_ajax; ?>';
  var sc_ajaxBordS = '<?php echo $this->Ini->Border_s_ajax; ?>';
  var sc_ajaxBordW = '<?php echo $this->Ini->Border_w_ajax; ?>';
  var sc_ajaxMsgTime = 2;
  var sc_img_status_ok = '<?php echo $this->Ini->path_icones; ?>/<?php echo $this->Ini->Img_status_ok; ?>';
  var sc_img_status_err = '<?php echo $this->Ini->path_icones; ?>/<?php echo $this->Ini->Img_status_err; ?>';
  var sc_css_status = '<?php echo $this->Ini->Css_status; ?>';
<?php
if ($this->Embutida_form && isset($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['sc_modal']) && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['sc_modal'] && isset($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['sc_redir_atualiz']) && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['sc_redir_atualiz'] == 'ok')
{
?>
  var sc_closeChange = true;
<?php
}
else
{
?>
  var sc_closeChange = false;
<?php
}
?>
 </SCRIPT>
 <SCRIPT type="text/javascript" src="<?php echo $this->Ini->path_prod; ?>/third/jquery/js/jquery.js"></SCRIPT>
 <SCRIPT type="text/javascript" src="<?php echo $this->Ini->path_prod; ?>/third/jquery/js/jquery-ui.js"></SCRIPT>
 <link rel="stylesheet" href="<?php echo $this->Ini->path_prod ?>/third/jquery/css/smoothness/jquery-ui.css" type="text/css" media="screen" />
 <SCRIPT type="text/javascript" src="<?php echo $this->Ini->path_prod; ?>/third/jquery_plugin/malsup-blockui/jquery.blockUI.js"></SCRIPT>
 <SCRIPT type="text/javascript" src="<?php echo $this->Ini->path_prod; ?>/third/jquery_plugin/thickbox/thickbox-compressed.js"></SCRIPT>
 <style type="text/css">
  #quicksearchph_t {
   position: relative;
  }
  #quicksearchph_t img {
   position: absolute;
   top: 0;
   right: 0;
  }
 </style>
 <SCRIPT type="text/javascript" src="<?php echo $this->Ini->url_lib_js; ?>jquery.scInput.js"></SCRIPT>
 <SCRIPT type="text/javascript" src="<?php echo $this->Ini->url_lib_js; ?>jquery.fieldSelection.js"></SCRIPT>
 <link rel="stylesheet" type="text/css" href="../_lib/css/<?php echo $this->Ini->str_schema_all ?>_form.css" />
 <link rel="stylesheet" type="text/css" href="../_lib/css/<?php echo $this->Ini->str_schema_all ?>_tab.css" />
 <link rel="stylesheet" type="text/css" href="../_lib/buttons/<?php echo $this->Ini->Str_btn_form . '/' . $this->Ini->Str_btn_form ?>.css" />
 <link rel="stylesheet" type="text/css" href="../_lib/css/<?php echo $this->Ini->str_schema_all ?>_calendar.css" />
<?php
include_once("../_lib/css/" . $this->Ini->str_schema_all . "_tab.php");
?>

<script>
var scFocusFirstErrorField = false;
var scFocusFirstErrorName  = "<?php echo $this->scFormFocusErrorName; ?>";
</script>

<?php
include_once("form_comprascotaresposta_sajax_js.php");
?>
<script type="text/javascript">
if (document.getElementById("id_error_display_fixed"))
{
 scCenterFixedElement("id_error_display_fixed");
}
var posDispLeft = 0;
var posDispTop = 0;
var Nm_Proc_Atualiz = false;
function findPos(obj)
{
 var posCurLeft = posCurTop = 0;
 if (obj.offsetParent)
 {
  posCurLeft = obj.offsetLeft
  posCurTop = obj.offsetTop
  while (obj = obj.offsetParent)
  {
   posCurLeft += obj.offsetLeft
   posCurTop += obj.offsetTop
  }
 }
 posDispLeft = posCurLeft - 10;
 posDispTop = posCurTop + 30;
}
var Nav_permite_ret = "<?php if ($this->Nav_permite_ret) { echo 'S'; } else { echo 'N'; } ?>";
var Nav_permite_ava = "<?php if ($this->Nav_permite_ava) { echo 'S'; } else { echo 'N'; } ?>";
var Nav_binicio     = "<?php echo $this->arr_buttons['binicio']['type']; ?>";
var Nav_binicio_off = "<?php echo $this->arr_buttons['binicio_off']['type']; ?>";
var Nav_bavanca     = "<?php echo $this->arr_buttons['bavanca']['type']; ?>";
var Nav_bavanca_off = "<?php echo $this->arr_buttons['bavanca_off']['type']; ?>";
var Nav_bretorna    = "<?php echo $this->arr_buttons['bretorna']['type']; ?>";
var Nav_bretorna_off = "<?php echo $this->arr_buttons['bretorna_off']['type']; ?>";
var Nav_bfinal      = "<?php echo $this->arr_buttons['bfinal']['type']; ?>";
var Nav_bfinal_off  = "<?php echo $this->arr_buttons['bfinal_off']['type']; ?>";
function nav_atualiza(str_ret, str_ava, str_pos)
{
 if ('S' == str_ret)
 {
  if (Nav_binicio == 'image')
  {
      if (document.getElementById("sc_b_ini_" + str_pos)) {
        sImg = document.getElementById("id_img_sc_b_ini_" + str_pos).src;
        nav_liga_img();
        document.getElementById("id_img_sc_b_ini_" + str_pos).src = sImg;
        document.getElementById("sc_b_ini_" + str_pos).disabled = false;
      }
  }
  else
  {
      if (document.getElementById("sc_b_ini_" + str_pos)){
        document.getElementById("sc_b_ini_" + str_pos).className = "scButton_<?php echo $this->arr_buttons['binicio']['style'] ?>";
        document.getElementById("sc_b_ini_" + str_pos).disabled = false;
        if('only_img' == '<?php echo $this->arr_buttons['binicio']['display']; ?>' || 'text_img' == '<?php echo $this->arr_buttons['binicio']['display']; ?>')
        {
            sImg = document.getElementById("id_img_sc_b_ini_" + str_pos).src;
            nav_liga_img();
            document.getElementById("id_img_sc_b_ini_" + str_pos).src = sImg;
        }
      }
  }
  if (Nav_bretorna == 'image')
  {
      if (document.getElementById("sc_b_ret_" + str_pos)) {
        sImg = document.getElementById("id_img_sc_b_ret_" + str_pos).src;
        nav_liga_img();
        document.getElementById("id_img_sc_b_ret_" + str_pos).src = sImg;
        document.getElementById("sc_b_ret_" + str_pos).disabled = false;
      }
  }
  else
  {
      if (document.getElementById("sc_b_ret_" + str_pos)) {
        document.getElementById("sc_b_ret_" + str_pos).className = "scButton_<?php echo $this->arr_buttons['bretorna']['style'] ?>";
        document.getElementById("sc_b_ret_" + str_pos).disabled = false;
        if('only_img' == '<?php echo $this->arr_buttons['bretorna']['display']; ?>' || 'text_img' == '<?php echo $this->arr_buttons['bretorna']['display']; ?>')
        {
            sImg = document.getElementById("id_img_sc_b_ret_" + str_pos).src;
            nav_liga_img();
            document.getElementById("id_img_sc_b_ret_" + str_pos).src = sImg;
        }
      }
  }
 }
 else
 {
  if (Nav_binicio_off == 'image')
  {
      if (document.getElementById("sc_b_ini_" + str_pos)) {
        sImg = document.getElementById("id_img_sc_b_ini_" + str_pos).src;
        nav_desliga_img();
        document.getElementById("id_img_sc_b_ini_" + str_pos).src = sImg;
        document.getElementById("sc_b_ini_" + str_pos).disabled = true;
      }
  }
  else
  {
      if (document.getElementById("sc_b_ini_" + str_pos)) {
        document.getElementById("sc_b_ini_" + str_pos).className = "scButton_<?php echo $this->arr_buttons['binicio_off']['style'] ?>";
        document.getElementById("sc_b_ini_" + str_pos).disabled = true;
        if('only_img' == '<?php echo $this->arr_buttons['binicio_off']['display']; ?>' || 'text_img' == '<?php echo $this->arr_buttons['binicio_off']['display']; ?>')
        {
            sImg = document.getElementById("id_img_sc_b_ini_" + str_pos).src;
            nav_desliga_img();
            document.getElementById("id_img_sc_b_ini_" + str_pos).src = sImg;
        }
      }
  }
  if (Nav_bretorna_off == 'image')
  {
      if (document.getElementById("sc_b_ret_" + str_pos)) {
        sImg = document.getElementById("id_img_sc_b_ret_" + str_pos).src;
        nav_desliga_img();
        document.getElementById("id_img_sc_b_ret_" + str_pos).src = sImg;
        document.getElementById("sc_b_ret_" + str_pos).disabled = true;
      }
  }
  else
  {
      if (document.getElementById("sc_b_ret_" + str_pos)) {
        document.getElementById("sc_b_ret_" + str_pos).className = "scButton_<?php echo $this->arr_buttons['bretorna_off']['style'] ?>";
        document.getElementById("sc_b_ret_" + str_pos).disabled = true;
        if('only_img' == '<?php echo $this->arr_buttons['bretorna_off']['display']; ?>' || 'text_img' == '<?php echo $this->arr_buttons['bretorna_off']['display']; ?>')
        {
            sImg = document.getElementById("id_img_sc_b_ret_" + str_pos).src;
            nav_desliga_img();
            document.getElementById("id_img_sc_b_ret_" + str_pos).src = sImg;
        }
      }
  }
 }
 if ('S' == str_ava)
 {
  if (Nav_bavanca == 'image')
  {
      if (document.getElementById("sc_b_avc_" + str_pos)) {
        sImg = document.getElementById("id_img_sc_b_avc_" + str_pos).src;
        nav_liga_img();
        document.getElementById("id_img_sc_b_avc_" + str_pos).src = sImg;
        document.getElementById("sc_b_avc_" + str_pos).disabled = false;
      }
  }
  else
  {
      if (document.getElementById("sc_b_avc_" + str_pos)) {
        document.getElementById("sc_b_avc_" + str_pos).className = "scButton_<?php echo $this->arr_buttons['bavanca']['style'] ?>";
        document.getElementById("sc_b_avc_" + str_pos).disabled = false;
        if('only_img' == '<?php echo $this->arr_buttons['bavanca']['display']; ?>' || 'text_img' == '<?php echo $this->arr_buttons['bavanca']['display']; ?>')
        {
            sImg = document.getElementById("id_img_sc_b_avc_" + str_pos).src;
            nav_liga_img();
            document.getElementById("id_img_sc_b_avc_" + str_pos).src = sImg;
        }
      }
  }
  if (Nav_bfinal == 'image')
  {
      if (document.getElementById("sc_b_fim_" + str_pos)) {
        sImg = document.getElementById("id_img_sc_b_fim_" + str_pos).src;
        nav_liga_img();
        document.getElementById("id_img_sc_b_fim_" + str_pos).src = sImg;
        document.getElementById("sc_b_fim_" + str_pos).disabled = false;
      }
  }
  else
  {
      if (document.getElementById("sc_b_fim_" + str_pos)) {
        document.getElementById("sc_b_fim_" + str_pos).className = "scButton_<?php echo $this->arr_buttons['bfinal']['style'] ?>";
        document.getElementById("sc_b_fim_" + str_pos).disabled = false;
        if('only_img' == '<?php echo $this->arr_buttons['bfinal']['display']; ?>' || 'text_img' == '<?php echo $this->arr_buttons['bfinal']['display']; ?>')
        {
            sImg = document.getElementById("id_img_sc_b_fim_" + str_pos).src;
            nav_liga_img();
            document.getElementById("id_img_sc_b_fim_" + str_pos).src = sImg;
        }
      }
  }
 }
 else
 {
  if (Nav_bavanca_off == 'image')
  {
      if (document.getElementById("sc_b_avc_" + str_pos)) {
        sImg = document.getElementById("id_img_sc_b_avc_" + str_pos).src;
        nav_desliga_img();
        document.getElementById("id_img_sc_b_avc_" + str_pos).src = sImg;
        document.getElementById("sc_b_avc_" + str_pos).disabled = true;
      }
  }
  else
  {
      if (document.getElementById("sc_b_avc_" + str_pos)) {
        document.getElementById("sc_b_avc_" + str_pos).className = "scButton_<?php echo $this->arr_buttons['bavanca_off']['style'] ?>";
        document.getElementById("sc_b_avc_" + str_pos).disabled = true;
        if('only_img' == '<?php echo $this->arr_buttons['bavanca_off']['display']; ?>' || 'text_img' == '<?php echo $this->arr_buttons['bavanca_off']['display']; ?>')
        {
            sImg = document.getElementById("id_img_sc_b_avc_" + str_pos).src;
            nav_desliga_img();
            document.getElementById("id_img_sc_b_avc_" + str_pos).src = sImg;
        }
      }
  }
  if (Nav_bfinal_off == 'image')
  {
      if (document.getElementById("sc_b_fim_" + str_pos)) {
        sImg = document.getElementById("id_img_sc_b_fim_" + str_pos).src;
        nav_desliga_img();
        document.getElementById("id_img_sc_b_fim_" + str_pos).src = sImg;
        document.getElementById("sc_b_fim_" + str_pos).disabled = true;
      }
  }
  else
  {
      if (document.getElementById("sc_b_fim_" + str_pos)) {
        document.getElementById("sc_b_fim_" + str_pos).className = "scButton_<?php echo $this->arr_buttons['bfinal_off']['style'] ?>";
        document.getElementById("sc_b_fim_" + str_pos).disabled = true;
        if('only_img' == '<?php echo $this->arr_buttons['bfinal_off']['display']; ?>' || 'text_img' == '<?php echo $this->arr_buttons['bfinal_off']['display']; ?>')
        {
            sImg = document.getElementById("id_img_sc_b_fim_" + str_pos).src;
            nav_desliga_img();
            document.getElementById("id_img_sc_b_fim_" + str_pos).src = sImg;
        }
      }
  }
 }
}
function nav_liga_img()
{
 sExt = sImg.substr(sImg.length - 4);
 sImg = sImg.substr(0, sImg.length - 4);
 if ('_off' == sImg.substr(sImg.length - 4))
 {
  sImg = sImg.substr(0, sImg.length - 4);
 }
 sImg += sExt;
}
function nav_desliga_img()
{
 sExt = sImg.substr(sImg.length - 4);
 sImg = sImg.substr(0, sImg.length - 4);
 if ('_off' != sImg.substr(sImg.length - 4))
 {
  sImg += '_off';
 }
 sImg += sExt;
}
function summary_atualiza(reg_ini, reg_qtd, reg_tot)
{
    nm_sumario = "[<?php echo $this->Ini->Nm_lang['lang_othr_smry_info']?>]";
    nm_sumario = nm_sumario.replace("?start?", reg_ini);
    nm_sumario = nm_sumario.replace("?final?", reg_qtd);
    nm_sumario = nm_sumario.replace("?total?", reg_tot);
    if (reg_qtd < 1) {
        nm_sumario = "";
    }
    document.getElementById("sc_b_summary_b").innerHTML = nm_sumario;
}
function navpage_atualiza(str_navpage)
{
    document.getElementById("sc_b_navpage_b").innerHTML = str_navpage;
}
<?php

include_once('form_comprascotaresposta_jquery.php');

?>

 var scQSInit = true;
 var scQSPos = {};
 $(function() {


  scJQGeneralAdd();

  $('#SC_fast_search_t').keyup(function(e) {
   scQuickSearchKeyUp('t', e);
  });
<?php
if (!$this->NM_ajax_flag && isset($this->NM_non_ajax_info['ajaxJavascript']) && !empty($this->NM_non_ajax_info['ajaxJavascript']))
{
    foreach ($this->NM_non_ajax_info['ajaxJavascript'] as $aFnData)
    {
?>
  <?php echo $aFnData[0]; ?>(<?php echo implode(', ', $aFnData[1]); ?>);

<?php
    }
}
?>
 });

   $(window).load(function() {
     scQuickSearchInit(false, '');
     $('#SC_fast_search_t').listen();
     scQuickSearchKeyUp('t', null);
     scQSInit = false;
   });
   function scQuickSearchSubmit_t() {
     nm_move('fast_search', 't');
   }

   function scQuickSearchInit(bPosOnly, sPos) {
     if (!bPosOnly) {
       if ('' == sPos || 't' == sPos) scQuickSearchSize('SC_fast_search_t', 'SC_fast_search_close_t', 'SC_fast_search_submit_t', 'quicksearchph_t');
     }
   }
   function scQuickSearchSize(sIdInput, sIdClose, sIdSubmit, sPlaceHolder) {
     var oInput = $('#' + sIdInput),
         oClose = $('#' + sIdClose),
         oSubmit = $('#' + sIdSubmit),
         oPlace = $('#' + sPlaceHolder),
         iInputP = parseInt(oInput.css('padding-right')) || 0,
         iInputB = parseInt(oInput.css('border-right-width')) || 0,
         iInputW = oInput.outerWidth(),
         iPlaceW = oPlace.outerWidth(),
         oInputO = oInput.offset(),
         oPlaceO = oPlace.offset(),
         iNewRight;
     iNewRight = (iPlaceW - iInputW) - (oInputO.left - oPlaceO.left) + iInputB + 1;
     oInput.css({
       'height': Math.max(oInput.height(), 16) + 'px',
       'padding-right': iInputP + 16 + <?php echo $this->Ini->Str_qs_image_padding ?> + 'px'
     });
     oClose.css({
       'right': iNewRight + <?php echo $this->Ini->Str_qs_image_padding ?> + 'px',
       'cursor': 'pointer'
     });
     oSubmit.css({
       'right': iNewRight + <?php echo $this->Ini->Str_qs_image_padding ?> + 'px',
       'cursor': 'pointer'
     });
   }
   function scQuickSearchKeyUp(sPos, e) {
     if ('' != scQSInitVal && $('#SC_fast_search_' + sPos).val() == scQSInitVal && scQSInit) {
       $('#SC_fast_search_close_' + sPos).show();
       $('#SC_fast_search_submit_' + sPos).hide();
     }
     else {
       $('#SC_fast_search_close_' + sPos).hide();
       $('#SC_fast_search_submit_' + sPos).show();
     }
     if (null != e) {
       var keyPressed = e.charCode || e.keyCode || e.which;
       if (13 == keyPressed) {
         if ('t' == sPos) scQuickSearchSubmit_t();
       }
     }
   }
 if($(".sc-ui-block-control").length) {
  preloadBlock = new Image();
  preloadBlock.src = "<?php echo $this->Ini->path_icones; ?>/" + sc_blockExp;
 }

 var show_block = {
  
 };

 function toggleBlock(e) {
  var block = e.data.block,
      block_id = $(block).attr("id");
      block_img = $("#" + block_id + " .sc-ui-block-control");

  if (1 >= block.rows.length) {
   return;
  }

  show_block[block_id] = !show_block[block_id];

  if (show_block[block_id]) {
    $(block).css("height", "100%");
    if (block_img.length) block_img.attr("src", changeImgName(block_img.attr("src"), sc_blockCol));
  }
  else {
    $(block).css("height", "");
    if (block_img.length) block_img.attr("src", changeImgName(block_img.attr("src"), sc_blockExp));
  }

  for (var i = 1; i < block.rows.length; i++) {
   if (show_block[block_id])
    $(block.rows[i]).show();
   else
    $(block.rows[i]).hide();
  }
 }

 function changeImgName(imgOld, imgNew) {
   var aOld = imgOld.split("/");
   aOld.pop();
   aOld.push(imgNew);
   return aOld.join("/");
 }

</script>
</HEAD>
<?php
$str_iframe_body = ('F' == $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] || 'R' == $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe']) ? 'margin: 2px;' : '';
 if (isset($_SESSION['nm_aba_bg_color']))
 {
     $this->Ini->cor_bg_grid = $_SESSION['nm_aba_bg_color'];
     $this->Ini->img_fun_pag = $_SESSION['nm_aba_bg_img'];
 }
if ($GLOBALS["erro_incl"] == 1)
{
    $this->nmgp_opcao = "novo";
    $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['opc_ant'] = "novo";
    $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['recarga'] = "novo";
}
if (empty($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['recarga']))
{
    $opcao_botoes = $this->nmgp_opcao;
}
else
{
    $opcao_botoes = $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['recarga'];
}
if ('novo' == $opcao_botoes && $this->Embutida_form)
{
    $opcao_botoes = 'inicio';
}
?>
<body class="scFormPage" style="<?php echo $str_iframe_body; ?>">
<?php

if (!isset($this->NM_ajax_info['param']['buffer_output']) || !$this->NM_ajax_info['param']['buffer_output'])
{
    echo $sOBContents;
}

?>
<script type="text/javascript" src="<?php  echo $this->Ini->path_js . "/nm_rpc.js" ?>"> 
</script> 
<div id="idJSSpecChar" style="display: none;"></div>
<script type="text/javascript">
function NM_tp_critica(TP)
{
    if (TP == 0 || TP == 1 || TP == 2)
    {
        nmdg_tipo_crit = TP;
    }
}
</script> 
<?php
 include_once("form_comprascotaresposta_js0.php");
?>
<script type="text/javascript" src="<?php echo str_replace("{str_idioma}", $this->Ini->str_lang, "../_lib/js/tab_erro_{str_idioma}.js"); ?>"> 
</script> 
<script type="text/javascript" src="<?php  echo $this->Ini->path_js . "/nm_rpc.js" ?>"> 
</script> 
<script type="text/javascript"> 
  sc_quant_excl = <?php echo count($sc_check_excl); ?>; 
 function setLocale(oSel)
 {
  var sLocale = "";
  if (-1 < oSel.selectedIndex)
  {
   sLocale = oSel.options[oSel.selectedIndex].value;
  }
  document.F1.nmgp_idioma_novo.value = sLocale;
 }
 function setSchema(oSel)
 {
  var sLocale = "";
  if (-1 < oSel.selectedIndex)
  {
   sLocale = oSel.options[oSel.selectedIndex].value;
  }
  document.F1.nmgp_schema_f.value = sLocale;
 }
 </script>
<form name="F1" method=post 
               action="form_comprascotaresposta.php" 
               target="_self"> 
<input type=hidden name="nm_form_submit" value="1">
<input type=hidden name="nmgp_idioma_novo" value="">
<input type=hidden name="nmgp_schema_f" value="">
<input type=hidden name="nmgp_url_saida" value="">
<input type=hidden name="nmgp_opcao" value="">
<input type=hidden name="nmgp_ancora" value="">
<input type=hidden name="nmgp_num_form" value="<?php  echo NM_encode_input($nmgp_num_form); ?>">
<input type=hidden name="nmgp_parms" value="">
<input type=hidden name="script_case_init" value="<?php  echo NM_encode_input($this->Ini->sc_page); ?>"> 
<input type=hidden name="script_case_session" value="<?php  echo NM_encode_input(session_id()); ?>"> 
<?php
$int_iframe_padding = ('F' == $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] || 'R' == $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe']) ? 0 : "0px";
?>
<?php
$_SESSION['scriptcase']['error_span_title']['form_comprascotaresposta'] = $this->Ini->Error_icon_span;
$_SESSION['scriptcase']['error_icon_title']['form_comprascotaresposta'] = '' != $this->Ini->Err_ico_title ? $this->Ini->path_icones . '/' . $this->Ini->Err_ico_title : '';
?>
<div style="display: none; position: absolute" id="id_error_display_table_frame">
<table class="scFormErrorTable">
<tr><?php if ($this->Ini->Error_icon_span && '' != $this->Ini->Err_ico_title) { ?><td style="padding: 0px" rowspan="2"><img src="<?php echo $this->Ini->path_icones; ?>/<?php echo $this->Ini->Err_ico_title; ?>" style="border-width: 0px" align="top"></td><?php } ?><td class="scFormErrorTitle"><table style="border-collapse: collapse; border-width: 0px; width: 100%"><tr><td class="scFormErrorTitleFont" style="padding: 0px; vertical-align: top; width: 100%"><?php if (!$this->Ini->Error_icon_span && '' != $this->Ini->Err_ico_title) { ?><img src="<?php echo $this->Ini->path_icones; ?>/<?php echo $this->Ini->Err_ico_title; ?>" style="border-width: 0px" align="top">&nbsp;<?php } ?>ERRO</td><td style="padding: 0px; vertical-align: top"><?php echo nmButtonOutput($this->arr_buttons, "berrm_clse", "scAjaxHideErrorDisplay('table')", "scAjaxHideErrorDisplay('table')", "", "", "", "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
</td></tr></table></td></tr>
<tr><td class="scFormErrorMessage"><span id="id_error_display_table_text"></span></td></tr>
</table>
</div>
<div style="display: none; position: absolute" id="id_message_display_frame">
 <table class="scFormMessageTable" id="id_message_display_content" style="width: 100%">
  <tr id="id_message_display_title_line">
   <td class="scFormMessageTitle" style="height: 20px"><?php
if ('' != $this->Ini->Msg_ico_title) {
?>
<img src="<?php echo $this->Ini->path_icones . '/' . $this->Ini->Msg_ico_title; ?>" style="border-width: 0px; vertical-align: middle">&nbsp;<?php
}
?>
<?php echo nmButtonOutput($this->arr_buttons, "bmessageclose", "_scAjaxMessageBtnClose()", "_scAjaxMessageBtnClose()", "id_message_display_close_icon", "", "", "float: right", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
<span id="id_message_display_title" style="vertical-align: middle"></span></td>
  </tr>
  <tr>
   <td class="scFormMessageMessage"><?php
if ('' != $this->Ini->Msg_ico_body) {
?>
<img id="id_message_display_body_icon" src="<?php echo $this->Ini->path_icones . '/' . $this->Ini->Msg_ico_body; ?>" style="border-width: 0px; vertical-align: middle">&nbsp;<?php
}
?>
<span id="id_message_display_text"></span><div id="id_message_display_buttond" style="display: none; text-align: center"><br /><input id="id_message_display_buttone" type="button" class="scButton_default" value="Ok" onClick="_scAjaxMessageBtnClick()" ></div></td>
  </tr>
 </table>
</div>
<script type="text/javascript">
var scMsgDefTitle = "<?php echo $this->Ini->Nm_lang['lang_usr_lang_othr_msgs_titl']; ?>";
var scMsgDefButton = "Ok";
var scMsgDefClick = "close";
var scMsgDefScInit = "<?php echo $this->Ini->page; ?>";
</script>
<table id="main_table_form"  align="center" cellpadding="<?php echo $int_iframe_padding; ?>" class="scFormBorder" >
<?php
  if (!$this->Embutida_call && (!isset($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['mostra_cab']) || $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['mostra_cab'] != "N"))
  {
?>
<tr><td>
<style>
#lin1_col1 { padding-left:9px; padding-top:7px;  height:27px; overflow:hidden; text-align:left;}			 
#lin1_col2 { padding-right:9px; padding-top:7px; height:27px; text-align:right; overflow:hidden;   font-size:12px; font-weight:normal;}
</style>

<div style="width: 100%">
 <div class="scFormHeader" style="height:11px; display: block; border-width:0px; "></div>
 <div style="height:37px; background-color:#FFFFFF; border-width:0px 0px 1px 0px;  border-style: dashed; border-color:#ddd; display: block">
 	<table style="width:100%; border-collapse:collapse; padding:0;">
    	<tr>
        	<td id="lin1_col1" class="scFormHeaderFont"><span><?php if ($this->nmgp_opcao == "novo") { echo "" . $this->Ini->Nm_lang['lang_othr_frmi_titl'] . " - comprascotaresposta"; } else { echo "" . $this->Ini->Nm_lang['lang_othr_frmu_titl'] . " - comprascotaresposta"; } ?></span></td>
            <td id="lin1_col2" class="scFormHeaderFont"><span><?php echo date($this->dateDefaultFormat()); ?></span></td>
        </tr>
    </table>		 
 </div>
</div>
</td></tr>
<?php
  }
?>
<tr><td>
<?php
if ((!$this->Embutida_form || !$this->Embutida_call || $this->Grid_editavel || ($this->Embutida_call && 'on' == $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['embutida_liga_form_btn_nav'])) && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R")
{
?>
    <table style="border-collapse: collapse; border-width: 0px; width: 100%"><tr><td class="scFormToolbar" style="padding: 0px; spacing: 0px">
    <table style="border-collapse: collapse; border-width: 0px; width: 100%">
    <tr> 
     <td nowrap align="left" valign="middle" width="33%" class="scFormToolbarPadding"> 
<?php
}
if ((!$this->Embutida_form || !$this->Embutida_call || $this->Grid_editavel || ($this->Embutida_call && 'on' == $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['embutida_liga_form_btn_nav'])) && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R")
{
    $NM_btn = false;
      if ($this->nmgp_botoes['qsearch'] == "on" && $opcao_botoes != "novo")
      {
          $OPC_cmp = (isset($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['fast_search'])) ? $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['fast_search'][0] : "";
          $OPC_arg = (isset($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['fast_search'])) ? $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['fast_search'][1] : "";
          $OPC_dat = (isset($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['fast_search'])) ? $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['fast_search'][2] : "";
?> 
           <script type="text/javascript">var change_fast_t = "";</script>
          <input type="hidden" name="nmgp_fast_search_t" value="SC_all_Cmp">
          <input type="hidden" name="nmgp_cond_fast_search_t" value="qp">
          <script type="text/javascript">var scQSInitVal = "<?php echo $OPC_dat ?>";</script>
          <span id="quicksearchph_t">
           <input type="text" id="SC_fast_search_t" class="scFormToolbarInput" style="vertical-align: middle" name="nmgp_arg_fast_search_t" value="<?php echo NM_encode_input($OPC_dat) ?>" size="10" onChange="change_fast_t = 'CH';" alt="{watermark:'<?php echo $this->Ini->Nm_lang['lang_othr_qk_watermark'] ?>', watermarkClass: 'scFormToolbarInputWm', maxLength: 255}">
           <img style="position: absolute; display: none; height: 16px; width: 16px" id="SC_fast_search_close_t" src="<?php echo $this->Ini->path_botoes ?>/<?php echo $this->Ini->Img_qs_clean; ?>" onclick="document.getElementById('SC_fast_search_t').value = ''; nm_move('fast_search', 't');">
           <img style="position: absolute; display: none; height: 16px; width: 16px" id="SC_fast_search_submit_t" src="<?php echo $this->Ini->path_botoes ?>/<?php echo $this->Ini->Img_qs_search; ?>" onclick="scQuickSearchSubmit_t();">
          </span>
<?php 
      }
?> 
     </td> 
     <td nowrap align="center" valign="middle" width="33%" class="scFormToolbarPadding"> 
<?php 
    if (($opcao_botoes != "novo") && (!isset($this->Grid_editavel) || !$this->Grid_editavel) && (!$this->Embutida_form) && (!$this->Embutida_call || $this->Embutida_multi)) {
        $sCondStyle = ($this->nmgp_botoes['update'] == "on") ? '' : 'display: none;';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "balterarsel", "nm_atualiza ('alterar'); return false;", "nm_atualiza ('alterar'); return false;", "sc_b_upd_t", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
        $NM_btn = true;
    }
    if ($opcao_botoes != "novo") {
        $sCondStyle = ($this->nmgp_botoes['delete'] == "on") ? '' : 'display: none;';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "bexcluirsel", "nm_atualiza ('excluir'); return false;", "nm_atualiza ('excluir'); return false;", "sc_b_del_t", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
        $NM_btn = true;
    }
?> 
     </td> 
     <td nowrap align="right" valign="middle" width="33%" class="scFormToolbarPadding"> 
<?php 
    if ('' != $this->url_webhelp) {
        $sCondStyle = '';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "bhelp", "window.open('" . $this->url_webhelp. "', '', 'resizable, scrollbars'); ", "window.open('" . $this->url_webhelp. "', '', 'resizable, scrollbars'); ", "", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
        $NM_btn = true;
    }
    if (!$this->Embutida_call) {
        $sCondStyle = (isset($_SESSION['scriptcase']['nm_sc_retorno']) && !empty($_SESSION['scriptcase']['nm_sc_retorno']) && $nm_apl_dependente != 1 && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R" && (!$this->aba_iframe || $this->is_calendar_app) && $this->nmgp_botoes['exit'] == "on") ? '' : 'display: none;';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "bsair", "document.F6.action='" . $nm_url_saida. "'; document.F6.submit(); return false;", "document.F6.action='" . $nm_url_saida. "'; document.F6.submit(); return false;", "sc_b_sai_t", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
        $NM_btn = true;
    }
    if (!$this->Embutida_call) {
        $sCondStyle = (!isset($_SESSION['scriptcase']['nm_sc_retorno']) || empty($_SESSION['scriptcase']['nm_sc_retorno']) || $nm_apl_dependente == 1 || $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] == "F" || $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] == "R" || $this->aba_iframe || $this->nmgp_botoes['exit'] != "on") && ($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F" && $this->nmgp_botoes['exit'] == "on") && ($nm_apl_dependente == 1 && $this->nmgp_botoes['exit'] == "on") ? '' : 'display: none;';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "bvoltar", "document.F6.action='" . $nm_url_saida. "'; document.F6.submit(); return false;", "document.F6.action='" . $nm_url_saida. "'; document.F6.submit(); return false;", "sc_b_sai_t", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
        $NM_btn = true;
    }
    if (!$this->Embutida_call) {
        $sCondStyle = (!isset($_SESSION['scriptcase']['nm_sc_retorno']) || empty($_SESSION['scriptcase']['nm_sc_retorno']) || $nm_apl_dependente == 1 || $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] == "F" || $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] == "R" || $this->aba_iframe || $this->nmgp_botoes['exit'] != "on") && ($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F" && $this->nmgp_botoes['exit'] == "on") && ($nm_apl_dependente != 1 || $this->nmgp_botoes['exit'] != "on") && (!$this->aba_iframe && $this->nmgp_botoes['exit'] == "on") ? '' : 'display: none;';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "bsair", "document.F6.action='" . $nm_url_saida. "'; document.F6.submit(); return false;", "document.F6.action='" . $nm_url_saida. "'; document.F6.submit(); return false;", "sc_b_sai_t", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
        $NM_btn = true;
    }
}
if ((!$this->Embutida_form || !$this->Embutida_call || $this->Grid_editavel || ($this->Embutida_call && 'on' == $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['embutida_liga_form_btn_nav'])) && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R")
{
?>
   </td></tr> 
   </table> 
   </td></tr></table> 
<?php
}
?>
<?php
if (!$NM_btn && isset($NM_ult_sep))
{
    echo "    <script language=\"javascript\">";
    echo "      document.getElementById('" .  $NM_ult_sep . "').style.display='none';";
    echo "    </script>";
}
unset($NM_ult_sep);
?>
<?php if ('novo' != $this->nmgp_opcao || $this->Embutida_form) { ?><script>nav_atualiza(Nav_permite_ret, Nav_permite_ava, 't');</script><?php } ?>
</td></tr> 
<tr><td>
<?php
  if ($this->nmgp_form_empty)
  {
       echo "</td></tr><tr><td align=center>";
       echo "<font face=\"" . $this->Ini->pag_fonte_tipo . "\" color=\"" . $this->Ini->cor_txt_grid . "\" size=\"2\"><b>" . $this->Ini->Nm_lang['lang_errm_empt'] . "</b></font>";
       echo "</td></tr>";
       echo "<tr><td>";
  }
?>
<?php $sc_hidden_no = 1; $sc_hidden_yes = 0; ?>
   <a name="bloco_0"></a>
   <table width="100%" height="100%" cellpadding="0"><tr valign="top"><td width="100%" height="">
<div id="div_hidden_bloco_0"><!-- bloco_c -->
     <div id="SC_tab_mult_reg">
<?php
}

function Form_Table($Table_refresh = false)
{
   global $sc_seq_vert, $nm_apl_dependente, $opcao_botoes, $nm_url_saida; 
   if ($Table_refresh) 
   { 
       ob_start();
   }
?>
<?php
?>
<TABLE align="center" id="hidden_bloco_0" class="scFormTable" width="100%" style="height: 100%;">   <tr>
<?php
$orderColName = '';
$orderColOrient = '';
?>
    <script type="text/javascript">
     var orderImgAsc = "<?php echo $this->Ini->path_img_global . "/" . $this->Ini->Label_sort_asc ?>";
     var orderImgDesc = "<?php echo $this->Ini->path_img_global . "/" . $this->Ini->Label_sort_desc ?>";
     var orderImgNone = "<?php echo $this->Ini->path_img_global . "/" . $this->Ini->Label_sort ?>";
     var orderColName = "";
     function scSetOrderColumn(clickedColumn) {
      $(".sc-ui-img-order-column").attr("src", orderImgNone);
      if (clickedColumn != orderColName) {
       orderColName = clickedColumn;
       orderColOrient = orderImgAsc;
      }
      else if ("" != orderColName) {
       orderColOrient = orderColOrient == orderImgAsc ? orderImgDesc : orderImgAsc;
      }
      else {
       orderColName = "";
       orderColOrient = "";
      }
      $("#sc-id-img-order-" + orderColName).attr("src", orderColOrient);
     }
    </script>
<?php
     $Col_span = "";


       if (!$this->Embutida_form && $this->nmgp_opcao != "novo" && ($this->nmgp_botoes['delete'] == "on" || $this->nmgp_botoes['update'] == "on")) { $Col_span = " colspan=2"; }
 ?>

    <TD class="scFormLabelOddMult" <?php echo $Col_span ?>> &nbsp; </TD>
   
   <?php if ($this->Embutida_form && $this->nmgp_botoes['insert'] == "on") {?>
    <TD class="scFormLabelOddMult"  width="10">  </TD>
   <?php }?>
   <?php if ($this->Embutida_form && $this->nmgp_botoes['insert'] != "on") {?>
    <TD class="scFormLabelOddMult"  width="10"> &nbsp; </TD>
   <?php }?>
   <?php if (isset($this->nmgp_cmp_hidden['cadunid']) && $this->nmgp_cmp_hidden['cadunid'] == 'off') { $sStyleHidden_cadunid = 'display: none'; }
      if (1 || !isset($this->nmgp_cmp_hidden['cadunid']) || $this->nmgp_cmp_hidden['cadunid'] == 'on') {
      if (!isset($this->nm_new_label['cadunid'])) {
          $this->nm_new_label['cadunid'] = "Fornecedor"; } ?>

    <TD class="scFormLabelOddMult" id="hidden_field_label_cadunid" style="text-align:left;<?php echo $sStyleHidden_cadunid; ?>" >       
<?php
      $link_img = "";
      $SC_Label = "" . $this->nm_new_label['cadunid']  . "";
      $nome_img = $this->Ini->Label_sort;
      if ($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['ordem_cmp'] == "cadUnID")
      {
          $orderColName = "cadUnID";
          if ($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['ordem_ord'] == " desc")
          {
              $orderColOrient = $nome_img = $this->Ini->Label_sort_desc;
          }
          else
          {
              $orderColOrient = $nome_img = $this->Ini->Label_sort_asc;
          }
      }
      if (empty($this->Ini->Label_sort_pos))
      {
          $this->Ini->Label_sort_pos = "right_field";
      }
      if (empty($nome_img))
      {
          $link_img = $SC_Label;
      }
      elseif ($this->Ini->Label_sort_pos == "right_field")
      {
          $link_img = $SC_Label . "<IMG SRC=\"" . $this->Ini->path_img_global . "/" . $nome_img . "\" BORDER=\"0\" class=\"sc-ui-img-order-column\" id=\"sc-id-img-order-cadUnID\" />";
      }
      elseif ($this->Ini->Label_sort_pos == "left_field")
      {
          $link_img = "<IMG SRC=\"" . $this->Ini->path_img_global . "/" . $nome_img . "\" BORDER=\"0\" class=\"sc-ui-img-order-column\" id=\"sc-id-img-order-cadUnID\" />" . $SC_Label;
      }
      elseif ($this->Ini->Label_sort_pos == "right_cell")
      {
          $link_img = "<IMG style=\"float: right\" SRC=\"" . $this->Ini->path_img_global . "/" . $nome_img . "\" BORDER=\"0\" class=\"sc-ui-img-order-column\" id=\"sc-id-img-order-cadUnID\" />" . $SC_Label;
      }
      elseif ($this->Ini->Label_sort_pos == "left_cell")
      {
          $link_img = "<IMG style=\"float: left\" SRC=\"" . $this->Ini->path_img_global . "/" . $nome_img . "\" BORDER=\"0\" class=\"sc-ui-img-order-column\" id=\"sc-id-img-order-cadUnID\" />" . $SC_Label;
      }
      ?>
<a href="javascript:nm_move('ordem', 'cadUnID')" class="scFormLabelLink scFormLabelLinkOddMult"><?php echo $link_img ?></a> </TD>
   <?php } ?>

   <?php if (isset($this->nmgp_cmp_hidden['cotaitensid']) && $this->nmgp_cmp_hidden['cotaitensid'] == 'off') { $sStyleHidden_cotaitensid = 'display: none'; }
      if (1 || !isset($this->nmgp_cmp_hidden['cotaitensid']) || $this->nmgp_cmp_hidden['cotaitensid'] == 'on') {
      if (!isset($this->nm_new_label['cotaitensid'])) {
          $this->nm_new_label['cotaitensid'] = "Material"; } ?>

    <TD class="scFormLabelOddMult" id="hidden_field_label_cotaitensid" style="text-align:left;<?php echo $sStyleHidden_cotaitensid; ?>" >       
<?php
      $link_img = "";
      $SC_Label = "" . $this->nm_new_label['cotaitensid']  . "";
      $nome_img = $this->Ini->Label_sort;
      if ($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['ordem_cmp'] == "cotaItensID")
      {
          $orderColName = "cotaItensID";
          if ($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['ordem_ord'] == " desc")
          {
              $orderColOrient = $nome_img = $this->Ini->Label_sort_desc;
          }
          else
          {
              $orderColOrient = $nome_img = $this->Ini->Label_sort_asc;
          }
      }
      if (empty($this->Ini->Label_sort_pos))
      {
          $this->Ini->Label_sort_pos = "right_field";
      }
      if (empty($nome_img))
      {
          $link_img = $SC_Label;
      }
      elseif ($this->Ini->Label_sort_pos == "right_field")
      {
          $link_img = $SC_Label . "<IMG SRC=\"" . $this->Ini->path_img_global . "/" . $nome_img . "\" BORDER=\"0\" class=\"sc-ui-img-order-column\" id=\"sc-id-img-order-cotaItensID\" />";
      }
      elseif ($this->Ini->Label_sort_pos == "left_field")
      {
          $link_img = "<IMG SRC=\"" . $this->Ini->path_img_global . "/" . $nome_img . "\" BORDER=\"0\" class=\"sc-ui-img-order-column\" id=\"sc-id-img-order-cotaItensID\" />" . $SC_Label;
      }
      elseif ($this->Ini->Label_sort_pos == "right_cell")
      {
          $link_img = "<IMG style=\"float: right\" SRC=\"" . $this->Ini->path_img_global . "/" . $nome_img . "\" BORDER=\"0\" class=\"sc-ui-img-order-column\" id=\"sc-id-img-order-cotaItensID\" />" . $SC_Label;
      }
      elseif ($this->Ini->Label_sort_pos == "left_cell")
      {
          $link_img = "<IMG style=\"float: left\" SRC=\"" . $this->Ini->path_img_global . "/" . $nome_img . "\" BORDER=\"0\" class=\"sc-ui-img-order-column\" id=\"sc-id-img-order-cotaItensID\" />" . $SC_Label;
      }
      ?>
<a href="javascript:nm_move('ordem', 'cotaItensID')" class="scFormLabelLink scFormLabelLinkOddMult"><?php echo $link_img ?></a> </TD>
   <?php } ?>

   <?php if (isset($this->nmgp_cmp_hidden['statuscompraitem']) && $this->nmgp_cmp_hidden['statuscompraitem'] == 'off') { $sStyleHidden_statuscompraitem = 'display: none'; }
      if (1 || !isset($this->nmgp_cmp_hidden['statuscompraitem']) || $this->nmgp_cmp_hidden['statuscompraitem'] == 'on') {
      if (!isset($this->nm_new_label['statuscompraitem'])) {
          $this->nm_new_label['statuscompraitem'] = "Status Compra Item"; } ?>

    <TD class="scFormLabelOddMult" id="hidden_field_label_statuscompraitem" style=";<?php echo $sStyleHidden_statuscompraitem; ?>" > <?php echo $this->nm_new_label['statuscompraitem'] ?><br /><input type="checkbox" id="sc-ui-checkbox-statuscompraitem-control" /> </TD>
   <?php } ?>

   <?php if (isset($this->nmgp_cmp_hidden['statusmelhorpreco']) && $this->nmgp_cmp_hidden['statusmelhorpreco'] == 'off') { $sStyleHidden_statusmelhorpreco = 'display: none'; }
      if (1 || !isset($this->nmgp_cmp_hidden['statusmelhorpreco']) || $this->nmgp_cmp_hidden['statusmelhorpreco'] == 'on') {
      if (!isset($this->nm_new_label['statusmelhorpreco'])) {
          $this->nm_new_label['statusmelhorpreco'] = "Status Melhor Preco"; } ?>

    <TD class="scFormLabelOddMult" id="hidden_field_label_statusmelhorpreco" style=";<?php echo $sStyleHidden_statusmelhorpreco; ?>" > <?php echo $this->nm_new_label['statusmelhorpreco'] ?><br /><input type="checkbox" id="sc-ui-checkbox-statusmelhorpreco-control" /> </TD>
   <?php } ?>

   <?php if (isset($this->nmgp_cmp_hidden['valorunitario']) && $this->nmgp_cmp_hidden['valorunitario'] == 'off') { $sStyleHidden_valorunitario = 'display: none'; }
      if (1 || !isset($this->nmgp_cmp_hidden['valorunitario']) || $this->nmgp_cmp_hidden['valorunitario'] == 'on') {
      if (!isset($this->nm_new_label['valorunitario'])) {
          $this->nm_new_label['valorunitario'] = "V. Unit�rio"; } ?>

    <TD class="scFormLabelOddMult" id="hidden_field_label_valorunitario" style="text-align:center;<?php echo $sStyleHidden_valorunitario; ?>" > <?php echo $this->nm_new_label['valorunitario'] ?> </TD>
   <?php } ?>

   <?php if (isset($this->nmgp_cmp_hidden['condicaoentrega']) && $this->nmgp_cmp_hidden['condicaoentrega'] == 'off') { $sStyleHidden_condicaoentrega = 'display: none'; }
      if (1 || !isset($this->nmgp_cmp_hidden['condicaoentrega']) || $this->nmgp_cmp_hidden['condicaoentrega'] == 'on') {
      if (!isset($this->nm_new_label['condicaoentrega'])) {
          $this->nm_new_label['condicaoentrega'] = "Condicao Entrega"; } ?>

    <TD class="scFormLabelOddMult" id="hidden_field_label_condicaoentrega" style=";<?php echo $sStyleHidden_condicaoentrega; ?>" > <?php echo $this->nm_new_label['condicaoentrega'] ?> </TD>
   <?php } ?>

   <?php if (isset($this->nmgp_cmp_hidden['condicaopagamento']) && $this->nmgp_cmp_hidden['condicaopagamento'] == 'off') { $sStyleHidden_condicaopagamento = 'display: none'; }
      if (1 || !isset($this->nmgp_cmp_hidden['condicaopagamento']) || $this->nmgp_cmp_hidden['condicaopagamento'] == 'on') {
      if (!isset($this->nm_new_label['condicaopagamento'])) {
          $this->nm_new_label['condicaopagamento'] = "Condicao Pagamento"; } ?>

    <TD class="scFormLabelOddMult" id="hidden_field_label_condicaopagamento" style=";<?php echo $sStyleHidden_condicaopagamento; ?>" > <?php echo $this->nm_new_label['condicaopagamento'] ?> </TD>
   <?php } ?>





    <script type="text/javascript">
     var orderColOrient = "<?php echo $orderColOrient ?>";
     scSetOrderColumn("<?php echo $orderColName ?>");
    </script>
   </tr>
<?php   
} 
function Form_Corpo($Line_Add = false, $Table_refresh = false) 
{ 
   global $sc_seq_vert; 
   if ($Line_Add) 
   { 
       ob_start();
       $iStart = sizeof($this->form_vert_form_comprascotaresposta);
       $guarda_nmgp_opcao = $this->nmgp_opcao;
       $guarda_form_vert_form_comprascotaresposta = $this->form_vert_form_comprascotaresposta;
       $this->nmgp_opcao = 'novo';
   } 
   if ($this->Embutida_form && empty($this->form_vert_form_comprascotaresposta))
   {
       $sc_seq_vert = 0;
   }
   foreach ($this->form_vert_form_comprascotaresposta as $sc_seq_vert => $sc_lixo)
   {
       $this->cotarespostaid = $this->form_vert_form_comprascotaresposta[$sc_seq_vert]['cotarespostaid'];
       $this->cotadocid = $this->form_vert_form_comprascotaresposta[$sc_seq_vert]['cotadocid'];
       if (isset($this->Embutida_ronly) && $this->Embutida_ronly && !$Line_Add)
       {
           $this->nmgp_cmp_readonly['cadunid'] = true;
           $this->nmgp_cmp_readonly['cotaitensid'] = true;
           $this->nmgp_cmp_readonly['statuscompraitem'] = true;
           $this->nmgp_cmp_readonly['statusmelhorpreco'] = true;
           $this->nmgp_cmp_readonly['valorunitario'] = true;
           $this->nmgp_cmp_readonly['condicaoentrega'] = true;
           $this->nmgp_cmp_readonly['condicaopagamento'] = true;
       }
       elseif ($Line_Add)
       {
           if (!isset($this->nmgp_cmp_readonly['cadunid']) || $this->nmgp_cmp_readonly['cadunid'] != "on") {$this->nmgp_cmp_readonly['cadunid'] = false;}
           if (!isset($this->nmgp_cmp_readonly['cotaitensid']) || $this->nmgp_cmp_readonly['cotaitensid'] != "on") {$this->nmgp_cmp_readonly['cotaitensid'] = false;}
           if (!isset($this->nmgp_cmp_readonly['statuscompraitem']) || $this->nmgp_cmp_readonly['statuscompraitem'] != "on") {$this->nmgp_cmp_readonly['statuscompraitem'] = false;}
           if (!isset($this->nmgp_cmp_readonly['statusmelhorpreco']) || $this->nmgp_cmp_readonly['statusmelhorpreco'] != "on") {$this->nmgp_cmp_readonly['statusmelhorpreco'] = false;}
           if (!isset($this->nmgp_cmp_readonly['valorunitario']) || $this->nmgp_cmp_readonly['valorunitario'] != "on") {$this->nmgp_cmp_readonly['valorunitario'] = false;}
           if (!isset($this->nmgp_cmp_readonly['condicaoentrega']) || $this->nmgp_cmp_readonly['condicaoentrega'] != "on") {$this->nmgp_cmp_readonly['condicaoentrega'] = false;}
           if (!isset($this->nmgp_cmp_readonly['condicaopagamento']) || $this->nmgp_cmp_readonly['condicaopagamento'] != "on") {$this->nmgp_cmp_readonly['condicaopagamento'] = false;}
       }
              foreach ($this->form_vert_form_preenchimento[$sc_seq_vert] as $sCmpNome => $mCmpVal)
              {
                  eval("\$this->" . $sCmpNome . " = \$mCmpVal;");
              }
        $this->cadunid = $this->form_vert_form_comprascotaresposta[$sc_seq_vert]['cadunid']; 
       $cadunid = $this->cadunid; 
       $sStyleHidden_cadunid = '';
       if (isset($sCheckRead_cadunid))
       {
           unset($sCheckRead_cadunid);
       }
       if (isset($this->nmgp_cmp_readonly['cadunid']))
       {
           $sCheckRead_cadunid = $this->nmgp_cmp_readonly['cadunid'];
       }
       if (isset($this->nmgp_cmp_hidden['cadunid']) && $this->nmgp_cmp_hidden['cadunid'] == 'off')
       {
           unset($this->nmgp_cmp_hidden['cadunid']);
           $sStyleHidden_cadunid = 'display: none;';
       }
       $bTestReadOnly_cadunid = true;
       $sStyleReadLab_cadunid = 'display: none;';
       $sStyleReadInp_cadunid = '';
       if (isset($this->nmgp_cmp_readonly['cadunid']) && $this->nmgp_cmp_readonly['cadunid'] == 'on')
       {
           $bTestReadOnly_cadunid = false;
           unset($this->nmgp_cmp_readonly['cadunid']);
           $sStyleReadLab_cadunid = '';
           $sStyleReadInp_cadunid = 'display: none;';
       }
       $this->cotaitensid = $this->form_vert_form_comprascotaresposta[$sc_seq_vert]['cotaitensid']; 
       $cotaitensid = $this->cotaitensid; 
       $sStyleHidden_cotaitensid = '';
       if (isset($sCheckRead_cotaitensid))
       {
           unset($sCheckRead_cotaitensid);
       }
       if (isset($this->nmgp_cmp_readonly['cotaitensid']))
       {
           $sCheckRead_cotaitensid = $this->nmgp_cmp_readonly['cotaitensid'];
       }
       if (isset($this->nmgp_cmp_hidden['cotaitensid']) && $this->nmgp_cmp_hidden['cotaitensid'] == 'off')
       {
           unset($this->nmgp_cmp_hidden['cotaitensid']);
           $sStyleHidden_cotaitensid = 'display: none;';
       }
       $bTestReadOnly_cotaitensid = true;
       $sStyleReadLab_cotaitensid = 'display: none;';
       $sStyleReadInp_cotaitensid = '';
       if (isset($this->nmgp_cmp_readonly['cotaitensid']) && $this->nmgp_cmp_readonly['cotaitensid'] == 'on')
       {
           $bTestReadOnly_cotaitensid = false;
           unset($this->nmgp_cmp_readonly['cotaitensid']);
           $sStyleReadLab_cotaitensid = '';
           $sStyleReadInp_cotaitensid = 'display: none;';
       }
       $this->statuscompraitem = $this->form_vert_form_comprascotaresposta[$sc_seq_vert]['statuscompraitem']; 
       $statuscompraitem = $this->statuscompraitem; 
       $sStyleHidden_statuscompraitem = '';
       if (isset($sCheckRead_statuscompraitem))
       {
           unset($sCheckRead_statuscompraitem);
       }
       if (isset($this->nmgp_cmp_readonly['statuscompraitem']))
       {
           $sCheckRead_statuscompraitem = $this->nmgp_cmp_readonly['statuscompraitem'];
       }
       if (isset($this->nmgp_cmp_hidden['statuscompraitem']) && $this->nmgp_cmp_hidden['statuscompraitem'] == 'off')
       {
           unset($this->nmgp_cmp_hidden['statuscompraitem']);
           $sStyleHidden_statuscompraitem = 'display: none;';
       }
       $bTestReadOnly_statuscompraitem = true;
       $sStyleReadLab_statuscompraitem = 'display: none;';
       $sStyleReadInp_statuscompraitem = '';
       if (isset($this->nmgp_cmp_readonly['statuscompraitem']) && $this->nmgp_cmp_readonly['statuscompraitem'] == 'on')
       {
           $bTestReadOnly_statuscompraitem = false;
           unset($this->nmgp_cmp_readonly['statuscompraitem']);
           $sStyleReadLab_statuscompraitem = '';
           $sStyleReadInp_statuscompraitem = 'display: none;';
       }
       $this->statusmelhorpreco = $this->form_vert_form_comprascotaresposta[$sc_seq_vert]['statusmelhorpreco']; 
       $statusmelhorpreco = $this->statusmelhorpreco; 
       $sStyleHidden_statusmelhorpreco = '';
       if (isset($sCheckRead_statusmelhorpreco))
       {
           unset($sCheckRead_statusmelhorpreco);
       }
       if (isset($this->nmgp_cmp_readonly['statusmelhorpreco']))
       {
           $sCheckRead_statusmelhorpreco = $this->nmgp_cmp_readonly['statusmelhorpreco'];
       }
       if (isset($this->nmgp_cmp_hidden['statusmelhorpreco']) && $this->nmgp_cmp_hidden['statusmelhorpreco'] == 'off')
       {
           unset($this->nmgp_cmp_hidden['statusmelhorpreco']);
           $sStyleHidden_statusmelhorpreco = 'display: none;';
       }
       $bTestReadOnly_statusmelhorpreco = true;
       $sStyleReadLab_statusmelhorpreco = 'display: none;';
       $sStyleReadInp_statusmelhorpreco = '';
       if (isset($this->nmgp_cmp_readonly['statusmelhorpreco']) && $this->nmgp_cmp_readonly['statusmelhorpreco'] == 'on')
       {
           $bTestReadOnly_statusmelhorpreco = false;
           unset($this->nmgp_cmp_readonly['statusmelhorpreco']);
           $sStyleReadLab_statusmelhorpreco = '';
           $sStyleReadInp_statusmelhorpreco = 'display: none;';
       }
       $this->valorunitario = $this->form_vert_form_comprascotaresposta[$sc_seq_vert]['valorunitario']; 
       $valorunitario = $this->valorunitario; 
       $sStyleHidden_valorunitario = '';
       if (isset($sCheckRead_valorunitario))
       {
           unset($sCheckRead_valorunitario);
       }
       if (isset($this->nmgp_cmp_readonly['valorunitario']))
       {
           $sCheckRead_valorunitario = $this->nmgp_cmp_readonly['valorunitario'];
       }
       if (isset($this->nmgp_cmp_hidden['valorunitario']) && $this->nmgp_cmp_hidden['valorunitario'] == 'off')
       {
           unset($this->nmgp_cmp_hidden['valorunitario']);
           $sStyleHidden_valorunitario = 'display: none;';
       }
       $bTestReadOnly_valorunitario = true;
       $sStyleReadLab_valorunitario = 'display: none;';
       $sStyleReadInp_valorunitario = '';
       if (isset($this->nmgp_cmp_readonly['valorunitario']) && $this->nmgp_cmp_readonly['valorunitario'] == 'on')
       {
           $bTestReadOnly_valorunitario = false;
           unset($this->nmgp_cmp_readonly['valorunitario']);
           $sStyleReadLab_valorunitario = '';
           $sStyleReadInp_valorunitario = 'display: none;';
       }
       $this->condicaoentrega = $this->form_vert_form_comprascotaresposta[$sc_seq_vert]['condicaoentrega']; 
       $condicaoentrega = $this->condicaoentrega; 
       $sStyleHidden_condicaoentrega = '';
       if (isset($sCheckRead_condicaoentrega))
       {
           unset($sCheckRead_condicaoentrega);
       }
       if (isset($this->nmgp_cmp_readonly['condicaoentrega']))
       {
           $sCheckRead_condicaoentrega = $this->nmgp_cmp_readonly['condicaoentrega'];
       }
       if (isset($this->nmgp_cmp_hidden['condicaoentrega']) && $this->nmgp_cmp_hidden['condicaoentrega'] == 'off')
       {
           unset($this->nmgp_cmp_hidden['condicaoentrega']);
           $sStyleHidden_condicaoentrega = 'display: none;';
       }
       $bTestReadOnly_condicaoentrega = true;
       $sStyleReadLab_condicaoentrega = 'display: none;';
       $sStyleReadInp_condicaoentrega = '';
       if (isset($this->nmgp_cmp_readonly['condicaoentrega']) && $this->nmgp_cmp_readonly['condicaoentrega'] == 'on')
       {
           $bTestReadOnly_condicaoentrega = false;
           unset($this->nmgp_cmp_readonly['condicaoentrega']);
           $sStyleReadLab_condicaoentrega = '';
           $sStyleReadInp_condicaoentrega = 'display: none;';
       }
       $this->condicaopagamento = $this->form_vert_form_comprascotaresposta[$sc_seq_vert]['condicaopagamento']; 
       $condicaopagamento = $this->condicaopagamento; 
       $sStyleHidden_condicaopagamento = '';
       if (isset($sCheckRead_condicaopagamento))
       {
           unset($sCheckRead_condicaopagamento);
       }
       if (isset($this->nmgp_cmp_readonly['condicaopagamento']))
       {
           $sCheckRead_condicaopagamento = $this->nmgp_cmp_readonly['condicaopagamento'];
       }
       if (isset($this->nmgp_cmp_hidden['condicaopagamento']) && $this->nmgp_cmp_hidden['condicaopagamento'] == 'off')
       {
           unset($this->nmgp_cmp_hidden['condicaopagamento']);
           $sStyleHidden_condicaopagamento = 'display: none;';
       }
       $bTestReadOnly_condicaopagamento = true;
       $sStyleReadLab_condicaopagamento = 'display: none;';
       $sStyleReadInp_condicaopagamento = '';
       if (isset($this->nmgp_cmp_readonly['condicaopagamento']) && $this->nmgp_cmp_readonly['condicaopagamento'] == 'on')
       {
           $bTestReadOnly_condicaopagamento = false;
           unset($this->nmgp_cmp_readonly['condicaopagamento']);
           $sStyleReadLab_condicaopagamento = '';
           $sStyleReadInp_condicaopagamento = 'display: none;';
       }

       $this->lookup_cadunid($look_rpc_cadunid);
       $this->lookup_cotaitensid($look_rpc_cotaitensid);
       $nm_cor_fun_vert = ($nm_cor_fun_vert == $this->Ini->cor_grid_impar ? $this->Ini->cor_grid_par : $this->Ini->cor_grid_impar);
       $nm_img_fun_cel  = ($nm_img_fun_cel  == $this->Ini->img_fun_imp    ? $this->Ini->img_fun_par  : $this->Ini->img_fun_imp);

       $sHideNewLine = '';
?>   
   <tr id="idVertRow<?php echo $sc_seq_vert; ?>"<?php echo $sHideNewLine; ?>>


   
    <TD class="scFormDataOddMult"  id="hidden_field_data_sc_seq<?php echo $sc_seq_vert; ?>" > <?php echo $sc_seq_vert; ?> </TD>
   
   <?php if (!$this->Embutida_form && $this->nmgp_opcao != "novo" && ($this->nmgp_botoes['delete'] == "on" || $this->nmgp_botoes['update'] == "on")) {?>
    <TD class="scFormDataOddMult" > 
<input type=checkbox name="sc_check_vert[<?php echo $sc_seq_vert ?>]" value="<?php echo $sc_seq_vert . "\""; if (in_array($sc_seq_vert, $sc_check_excl)) { echo " checked";} ?> onclick="if (this.checked) {sc_quant_excl++; } else {sc_quant_excl--; }"> </TD>
   <?php }?>
   <?php if ($this->Embutida_form) {?>
    <TD class="scFormDataOddMult"  id="hidden_field_data_sc_actions<?php echo $sc_seq_vert; ?>" NOWRAP> <?php if ($this->nmgp_botoes['delete'] == "on" && $this->nmgp_opcao != "novo") {?>
<?php echo nmButtonOutput($this->arr_buttons, "bmd_excluir", "nm_atualiza_line('excluir', " . $sc_seq_vert . ")", "nm_atualiza_line('excluir', " . $sc_seq_vert . ")", "sc_exc_line_" . $sc_seq_vert . "", "", "", "display: ''", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
<?php }?>

<?php
if ($this->nmgp_botoes['update'] == "on" && $this->nmgp_opcao != "novo") {
    if ($this->Embutida_ronly) {
?>
<?php echo nmButtonOutput($this->arr_buttons, "bmd_edit", "mdOpenLine(" . $sc_seq_vert . ")", "mdOpenLine(" . $sc_seq_vert . ")", "sc_open_line_" . $sc_seq_vert . "", "", "", "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
<?php
        $sButDisp = 'display: none';
    }
    else
    {
        $sButDisp = '';
    }
?>
<?php echo nmButtonOutput($this->arr_buttons, "bmd_alterar", "findPos(this); nm_atualiza_line('alterar', " . $sc_seq_vert . ")", "findPos(this); nm_atualiza_line('alterar', " . $sc_seq_vert . ")", "sc_upd_line_" . $sc_seq_vert . "", "", "", "" . $sButDisp. "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
<?php
}
?>

<?php if ($this->nmgp_botoes['insert'] == "on" && $this->nmgp_opcao == "novo") {?>
<?php echo nmButtonOutput($this->arr_buttons, "bmd_incluir", "findPos(this); nm_atualiza_line('incluir', " . $sc_seq_vert . ")", "findPos(this); nm_atualiza_line('incluir', " . $sc_seq_vert . ")", "sc_ins_line_" . $sc_seq_vert . "", "", "", "display: ''", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
<?php if ($this->nmgp_botoes['delete'] == "on") {?>
<?php echo nmButtonOutput($this->arr_buttons, "bmd_excluir", "nm_atualiza_line('excluir', " . $sc_seq_vert . ")", "nm_atualiza_line('excluir', " . $sc_seq_vert . ")", "sc_exc_line_" . $sc_seq_vert . "", "", "", "display: none", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
<?php }?>

<?php if ($Line_Add && $this->Embutida_ronly) {?>
<?php echo nmButtonOutput($this->arr_buttons, "bmd_edit", "mdOpenLine(" . $sc_seq_vert . ")", "mdOpenLine(" . $sc_seq_vert . ")", "sc_open_line_" . $sc_seq_vert . "", "", "", "display: none", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
<?php }?>

<?php if ($this->nmgp_botoes['update'] == "on") {?>
<?php echo nmButtonOutput($this->arr_buttons, "bmd_alterar", "findPos(this); nm_atualiza_line('alterar', " . $sc_seq_vert . ")", "findPos(this); nm_atualiza_line('alterar', " . $sc_seq_vert . ")", "sc_upd_line_" . $sc_seq_vert . "", "", "", "display: none", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
<?php }?>
<?php }?>
<?php if ($this->nmgp_botoes['insert'] == "on") {?>
<?php echo nmButtonOutput($this->arr_buttons, "bmd_novo", "do_ajax_form_comprascotaresposta_add_new_line(" . $sc_seq_vert . ")", "do_ajax_form_comprascotaresposta_add_new_line(" . $sc_seq_vert . ")", "sc_new_line_" . $sc_seq_vert . "", "", "", "display: none", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
<?php }?>
<?php
  $Style_add_line = (!$Line_Add) ? "display: none" : "";
?>
<?php echo nmButtonOutput($this->arr_buttons, "bmd_cancelar", "do_ajax_form_comprascotaresposta_cancel_insert(" . $sc_seq_vert . ")", "do_ajax_form_comprascotaresposta_cancel_insert(" . $sc_seq_vert . ")", "sc_canceli_line_" . $sc_seq_vert . "", "", "", "" . $Style_add_line . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
<?php echo nmButtonOutput($this->arr_buttons, "bmd_cancelar", "do_ajax_form_comprascotaresposta_cancel_update(" . $sc_seq_vert . ")", "do_ajax_form_comprascotaresposta_cancel_update(" . $sc_seq_vert . ")", "sc_cancelu_line_" . $sc_seq_vert . "", "", "", "display: none", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 </TD>
   <?php }?>
   <?php if (isset($this->nmgp_cmp_hidden['cadunid']) && $this->nmgp_cmp_hidden['cadunid'] == 'off') { $sc_hidden_yes++;  ?>
<input type=hidden name="cadunid<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($cadunid) . "\">"; ?>
<?php } else { $sc_hidden_no++; ?>

    <TD class="scFormDataOddMult" id="hidden_field_data_cadunid<?php echo $sc_seq_vert; ?>" style="<?php echo $sStyleHidden_cadunid; ?>text-align:left;"> <table style="border-width: 0px; border-collapse: collapse; width: 100%"><tr><td  class="scFormDataFontOddMult" style="text-align:left;;vertical-align: top;padding: 0px"><input type=hidden name="cadunid<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($cadunid); ?>"><span id="id_ajax_label_cadunid<?php echo $sc_seq_vert; ?>"><?php echo nl2br($cadunid); ?></span>
 <SPAN id="id_lookup_cadunid<?php echo $sc_seq_vert ?>"><?php echo $look_rpc_cadunid; ?></SPAN></td></tr><tr><td style="vertical-align: top; padding: 1px 0px 0px 0px"><table class="scFormFieldErrorTable" style="display: none" id="id_error_display_cadunid<?php echo $sc_seq_vert; ?>_frame"><tr><td class="scFormFieldErrorMessage"><span id="id_error_display_cadunid<?php echo $sc_seq_vert; ?>_text"></span></td></tr></table></td></tr></table> </TD>
   <?php }?>

   <?php if (isset($this->nmgp_cmp_hidden['cotaitensid']) && $this->nmgp_cmp_hidden['cotaitensid'] == 'off') { $sc_hidden_yes++;  ?>
<input type=hidden name="cotaitensid<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($cotaitensid) . "\">"; ?>
<?php } else { $sc_hidden_no++; ?>

    <TD class="scFormDataOddMult" id="hidden_field_data_cotaitensid<?php echo $sc_seq_vert; ?>" style="<?php echo $sStyleHidden_cotaitensid; ?>text-align:left;"> <table style="border-width: 0px; border-collapse: collapse; width: 100%"><tr><td  class="scFormDataFontOddMult" style="text-align:left;;vertical-align: top;padding: 0px"><input type=hidden name="cotaitensid<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($cotaitensid); ?>"><span id="id_ajax_label_cotaitensid<?php echo $sc_seq_vert; ?>"><?php echo nl2br($cotaitensid); ?></span>
 <SPAN id="id_lookup_cotaitensid<?php echo $sc_seq_vert ?>"><?php echo $look_rpc_cotaitensid; ?></SPAN></td></tr><tr><td style="vertical-align: top; padding: 1px 0px 0px 0px"><table class="scFormFieldErrorTable" style="display: none" id="id_error_display_cotaitensid<?php echo $sc_seq_vert; ?>_frame"><tr><td class="scFormFieldErrorMessage"><span id="id_error_display_cotaitensid<?php echo $sc_seq_vert; ?>_text"></span></td></tr></table></td></tr></table> </TD>
   <?php }?>

   <?php if (isset($this->nmgp_cmp_hidden['statuscompraitem']) && $this->nmgp_cmp_hidden['statuscompraitem'] == 'off') { $sc_hidden_yes++; ?>
<input type=hidden name="statuscompraitem<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($this->statuscompraitem) . "\">"; ?>
<?php } else { $sc_hidden_no++; ?>
<?php 
  if ($this->nmgp_opcao != "recarga") 
  {
      $this->statuscompraitem_1 = explode(";", trim($this->statuscompraitem));
  } 
  else
  {
      if (empty($this->statuscompraitem))
      {
          $this->statuscompraitem_1= array(); 
      } 
      else
      {
          $this->statuscompraitem_1= $this->statuscompraitem; 
          $this->statuscompraitem= ""; 
          foreach ($this->statuscompraitem_1 as $cada_statuscompraitem)
          {
             if (!empty($statuscompraitem))
             {
                 $this->statuscompraitem.= ";"; 
             } 
             $this->statuscompraitem.= $cada_statuscompraitem; 
          } 
      } 
  } 
?> 

    <TD class="scFormDataOddMult" id="hidden_field_data_statuscompraitem<?php echo $sc_seq_vert; ?>" style="<?php echo $sStyleHidden_statuscompraitem; ?>;"> <table style="border-width: 0px; border-collapse: collapse; width: 100%"><tr><td  class="scFormDataFontOddMult" style=";;vertical-align: top;padding: 0px">
<?php if ($bTestReadOnly_statuscompraitem && $this->nmgp_opcao != "novo" && isset($this->nmgp_cmp_readonly["statuscompraitem"]) &&  $this->nmgp_cmp_readonly["statuscompraitem"] == "on") { 

$statuscompraitem_look = "";
 if (in_array("S", $this->statuscompraitem_1))  { $statuscompraitem_look .= "Confirma&nbsp;";} 
?>
<input type=hidden name="statuscompraitem<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($statuscompraitem) . "\">" . $statuscompraitem_look . ""; ?>
<?php } else { ?>

<?php

$statuscompraitem_look = "";
 if (in_array("S", $this->statuscompraitem_1))  { $statuscompraitem_look .= "Confirma&nbsp;";} 
?>
<span id="id_read_on_statuscompraitem<?php echo $sc_seq_vert ; ?>" style=";<?php echo $sStyleReadLab_statuscompraitem; ?>"><?php echo NM_encode_input($statuscompraitem_look); ?></span><span id="id_read_off_statuscompraitem<?php echo $sc_seq_vert ; ?>" style="<?php echo $sStyleReadInp_statuscompraitem; ?>"><?php echo "<div id=\"idAjaxCheckbox_statuscompraitem" . $sc_seq_vert . "\">\r\n"; ?><TABLE><TR>
  <TD class="scFormDataFontOddMult" style=";"> <input type=checkbox class="sc-ui-checkbox-statuscompraitem sc-ui-checkbox-statuscompraitem<?php echo $sc_seq_vert ?>" name="statuscompraitem<?php echo $sc_seq_vert ?>[]" value="S"
<?php $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['Lookup_statuscompraitem'][] = 'S'; ?>
<?php  if (in_array("S", $this->statuscompraitem_1))  { echo " checked" ;} ?> onClick="nm_check_insert(<?php echo $sc_seq_vert ?>);" >Confirma</TD>
</TR></TABLE>
<?php echo "</div>\r\n"; ?></span><?php  }?>
</td></tr><tr><td style="vertical-align: top; padding: 1px 0px 0px 0px"><table class="scFormFieldErrorTable" style="display: none" id="id_error_display_statuscompraitem<?php echo $sc_seq_vert; ?>_frame"><tr><td class="scFormFieldErrorMessage"><span id="id_error_display_statuscompraitem<?php echo $sc_seq_vert; ?>_text"></span></td></tr></table></td></tr></table> </TD>
   <?php }?>

   <?php if (isset($this->nmgp_cmp_hidden['statusmelhorpreco']) && $this->nmgp_cmp_hidden['statusmelhorpreco'] == 'off') { $sc_hidden_yes++; ?>
<input type=hidden name="statusmelhorpreco<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($this->statusmelhorpreco) . "\">"; ?>
<?php } else { $sc_hidden_no++; ?>
<?php 
  if ($this->nmgp_opcao != "recarga") 
  {
      $this->statusmelhorpreco_1 = explode(";", trim($this->statusmelhorpreco));
  } 
  else
  {
      if (empty($this->statusmelhorpreco))
      {
          $this->statusmelhorpreco_1= array(); 
          $this->statusmelhorpreco= "N";
      } 
      else
      {
          $this->statusmelhorpreco_1= $this->statusmelhorpreco; 
          $this->statusmelhorpreco= ""; 
          foreach ($this->statusmelhorpreco_1 as $cada_statusmelhorpreco)
          {
             if (!empty($statusmelhorpreco))
             {
                 $this->statusmelhorpreco.= ";"; 
             } 
             $this->statusmelhorpreco.= $cada_statusmelhorpreco; 
          } 
      } 
  } 
?> 

    <TD class="scFormDataOddMult" id="hidden_field_data_statusmelhorpreco<?php echo $sc_seq_vert; ?>" style="<?php echo $sStyleHidden_statusmelhorpreco; ?>;"> <table style="border-width: 0px; border-collapse: collapse; width: 100%"><tr><td  class="scFormDataFontOddMult" style=";;vertical-align: top;padding: 0px">
<?php if ($bTestReadOnly_statusmelhorpreco && $this->nmgp_opcao != "novo" && isset($this->nmgp_cmp_readonly["statusmelhorpreco"]) &&  $this->nmgp_cmp_readonly["statusmelhorpreco"] == "on") { 

$statusmelhorpreco_look = "";
 if ($this->statusmelhorpreco == "S") { $statusmelhorpreco_look .= "Melhor" ;} 
?>
<input type=hidden name="statusmelhorpreco<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($statusmelhorpreco) . "\">" . $statusmelhorpreco_look . ""; ?>
<?php } else { ?>

<?php

$statusmelhorpreco_look = "";
 if ($this->statusmelhorpreco == "S") { $statusmelhorpreco_look .= "Melhor" ;} 
?>
<span id="id_read_on_statusmelhorpreco<?php echo $sc_seq_vert ; ?>" style=";<?php echo $sStyleReadLab_statusmelhorpreco; ?>"><?php echo NM_encode_input($statusmelhorpreco_look); ?></span><span id="id_read_off_statusmelhorpreco<?php echo $sc_seq_vert ; ?>" style="<?php echo $sStyleReadInp_statusmelhorpreco; ?>"><?php echo "<div id=\"idAjaxCheckbox_statusmelhorpreco" . $sc_seq_vert . "\">\r\n"; ?><TABLE><TR>
  <TD class="scFormDataFontOddMult" style=";"> <input type=checkbox class="sc-ui-checkbox-statusmelhorpreco sc-ui-checkbox-statusmelhorpreco<?php echo $sc_seq_vert ?>" name="statusmelhorpreco<?php echo $sc_seq_vert ?>[]" value="S"
<?php $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['Lookup_statusmelhorpreco'][] = 'S'; ?>
<?php  if (in_array("S", $this->statusmelhorpreco_1))  { echo " checked" ;} ?> onClick="nm_check_insert(<?php echo $sc_seq_vert ?>);" >Melhor</TD>
</TR></TABLE>
<?php echo "</div>\r\n"; ?></span><?php  }?>
</td></tr><tr><td style="vertical-align: top; padding: 1px 0px 0px 0px"><table class="scFormFieldErrorTable" style="display: none" id="id_error_display_statusmelhorpreco<?php echo $sc_seq_vert; ?>_frame"><tr><td class="scFormFieldErrorMessage"><span id="id_error_display_statusmelhorpreco<?php echo $sc_seq_vert; ?>_text"></span></td></tr></table></td></tr></table> </TD>
   <?php }?>

   <?php if (isset($this->nmgp_cmp_hidden['valorunitario']) && $this->nmgp_cmp_hidden['valorunitario'] == 'off') { $sc_hidden_yes++;  ?>
<input type=hidden name="valorunitario<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($valorunitario) . "\">"; ?>
<?php } else { $sc_hidden_no++; ?>

    <TD class="scFormDataOddMult" id="hidden_field_data_valorunitario<?php echo $sc_seq_vert; ?>" style="<?php echo $sStyleHidden_valorunitario; ?>text-align:right;"> <table style="border-width: 0px; border-collapse: collapse; width: 100%;float:right"><tr><td  class="scFormDataFontOddMult" style="text-align:right;;vertical-align: top;padding: 0px">
<?php if ($bTestReadOnly_valorunitario && $this->nmgp_opcao != "novo" && isset($this->nmgp_cmp_readonly["valorunitario"]) &&  $this->nmgp_cmp_readonly["valorunitario"] == "on") { 

 ?>
<input type=hidden name="valorunitario<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($valorunitario) . "\">" . $valorunitario . ""; ?>
<?php } else { ?>
<span id="id_read_on_valorunitario<?php echo $sc_seq_vert ?>" class="sc-ui-readonly-valorunitario<?php echo $sc_seq_vert ?>" style="text-align:right;<?php echo $sStyleReadLab_valorunitario; ?>"><?php echo NM_encode_input($this->valorunitario); ?></span><span id="id_read_off_valorunitario<?php echo $sc_seq_vert ?>" style="white-space: nowrap;<?php echo $sStyleReadInp_valorunitario; ?>">
 <input class="sc-js-input scFormObjectOddMult" style="text-align:right;" id="id_sc_field_valorunitario<?php echo $sc_seq_vert ?>" type=text name="valorunitario<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($valorunitario) ?>"
 size=12 alt="{datatype: 'decimal', maxLength: 12, precision: 2, decimalSep: '<?php echo str_replace("'", "\'", $this->field_config['valorunitario']['symbol_dec']); ?>', thousandsSep: '<?php echo str_replace("'", "\'", $this->field_config['valorunitario']['symbol_grp']); ?>', thousandsFormat: <?php echo $this->field_config['valorunitario']['symbol_fmt']; ?>, manualDecimals: false, allowNegative: false, onlyNegative: false, enterTab: false, enterSubmit: false, autoTab: false, selectOnFocus: true, watermark: '', watermarkClass: 'scFormObjectOddMultWm', maskChars: '(){}[].,;:-+/ '}"></span><?php } ?>
</td></tr><tr><td style="vertical-align: top; padding: 1px 0px 0px 0px"><table class="scFormFieldErrorTable" style="display: none" id="id_error_display_valorunitario<?php echo $sc_seq_vert; ?>_frame"><tr><td class="scFormFieldErrorMessage"><span id="id_error_display_valorunitario<?php echo $sc_seq_vert; ?>_text"></span></td></tr></table></td></tr></table> </TD>
   <?php }?>

   <?php if (isset($this->nmgp_cmp_hidden['condicaoentrega']) && $this->nmgp_cmp_hidden['condicaoentrega'] == 'off') { $sc_hidden_yes++;  ?>
<input type=hidden name="condicaoentrega<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($condicaoentrega) . "\">"; ?>
<?php } else { $sc_hidden_no++; ?>

    <TD class="scFormDataOddMult" id="hidden_field_data_condicaoentrega<?php echo $sc_seq_vert; ?>" style="<?php echo $sStyleHidden_condicaoentrega; ?>;"> <table style="border-width: 0px; border-collapse: collapse; width: 100%"><tr><td  class="scFormDataFontOddMult" style=";;vertical-align: top;padding: 0px">
<?php if ($bTestReadOnly_condicaoentrega && $this->nmgp_opcao != "novo" && isset($this->nmgp_cmp_readonly["condicaoentrega"]) &&  $this->nmgp_cmp_readonly["condicaoentrega"] == "on") { 

 ?>
<input type=hidden name="condicaoentrega<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($condicaoentrega) . "\">" . $condicaoentrega . ""; ?>
<?php } else { ?>
<span id="id_read_on_condicaoentrega<?php echo $sc_seq_vert ?>" class="sc-ui-readonly-condicaoentrega<?php echo $sc_seq_vert ?>" style=";<?php echo $sStyleReadLab_condicaoentrega; ?>"><?php echo NM_encode_input($this->condicaoentrega); ?></span><span id="id_read_off_condicaoentrega<?php echo $sc_seq_vert ?>" style="white-space: nowrap;<?php echo $sStyleReadInp_condicaoentrega; ?>">
 <input class="sc-js-input scFormObjectOddMult" style=";" id="id_sc_field_condicaoentrega<?php echo $sc_seq_vert ?>" type=text name="condicaoentrega<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($condicaoentrega) ?>"
 size=10 alt="{datatype: 'date', dateSep: '<?php echo $this->field_config['condicaoentrega']['date_sep']; ?>', dateFormat: '<?php echo $this->field_config['condicaoentrega']['date_format']; ?>', enterTab: false, enterSubmit: false, autoTab: false, selectOnFocus: true, watermark: '', watermarkClass: 'scFormObjectOddMultWm', maskChars: '(){}[].,;:-+/ '}"><?php
$tmp_form_data = $this->field_config['condicaoentrega']['date_format'];
$tmp_form_data = str_replace('aaaa', 'yyyy', $tmp_form_data);
$tmp_form_data = str_replace('dd'  , $this->Ini->Nm_lang['lang_othr_date_days'], $tmp_form_data);
$tmp_form_data = str_replace('mm'  , $this->Ini->Nm_lang['lang_othr_date_mnth'], $tmp_form_data);
$tmp_form_data = str_replace('yyyy', $this->Ini->Nm_lang['lang_othr_date_year'], $tmp_form_data);
$tmp_form_data = str_replace('hh'  , $this->Ini->Nm_lang['lang_othr_date_hour'], $tmp_form_data);
$tmp_form_data = str_replace('ii'  , $this->Ini->Nm_lang['lang_othr_date_mint'], $tmp_form_data);
$tmp_form_data = str_replace('ss'  , $this->Ini->Nm_lang['lang_othr_date_scnd'], $tmp_form_data);
$tmp_form_data = str_replace(';'   , ' '                                       , $tmp_form_data);
?>
</span><?php } ?>
</td></tr><tr><td style="vertical-align: top; padding: 1px 0px 0px 0px"><table class="scFormFieldErrorTable" style="display: none" id="id_error_display_condicaoentrega<?php echo $sc_seq_vert; ?>_frame"><tr><td class="scFormFieldErrorMessage"><span id="id_error_display_condicaoentrega<?php echo $sc_seq_vert; ?>_text"></span></td></tr></table></td></tr></table> </TD>
   <?php }?>

   <?php if (isset($this->nmgp_cmp_hidden['condicaopagamento']) && $this->nmgp_cmp_hidden['condicaopagamento'] == 'off') { $sc_hidden_yes++;  ?>
<input type=hidden name="condicaopagamento<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($condicaopagamento) . "\">"; ?>
<?php } else { $sc_hidden_no++; ?>

    <TD class="scFormDataOddMult" id="hidden_field_data_condicaopagamento<?php echo $sc_seq_vert; ?>" style="<?php echo $sStyleHidden_condicaopagamento; ?>;"> <table style="border-width: 0px; border-collapse: collapse; width: 100%"><tr><td  class="scFormDataFontOddMult" style=";;vertical-align: top;padding: 0px">
<?php if ($bTestReadOnly_condicaopagamento && $this->nmgp_opcao != "novo" && isset($this->nmgp_cmp_readonly["condicaopagamento"]) &&  $this->nmgp_cmp_readonly["condicaopagamento"] == "on") { 

 ?>
<input type=hidden name="condicaopagamento<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($condicaopagamento) . "\">" . $condicaopagamento . ""; ?>
<?php } else { ?>
<span id="id_read_on_condicaopagamento<?php echo $sc_seq_vert ?>" class="sc-ui-readonly-condicaopagamento<?php echo $sc_seq_vert ?>" style=";<?php echo $sStyleReadLab_condicaopagamento; ?>"><?php echo NM_encode_input($this->condicaopagamento); ?></span><span id="id_read_off_condicaopagamento<?php echo $sc_seq_vert ?>" style="white-space: nowrap;<?php echo $sStyleReadInp_condicaopagamento; ?>">
 <input class="sc-js-input scFormObjectOddMult" style=";" id="id_sc_field_condicaopagamento<?php echo $sc_seq_vert ?>" type=text name="condicaopagamento<?php echo $sc_seq_vert ?>" value="<?php echo NM_encode_input($condicaopagamento) ?>"
 size=20 maxlength=20 alt="{datatype: 'text', maxLength: 20, allowedChars: '', lettersCase: '', enterTab: false, enterSubmit: false, autoTab: false, selectOnFocus: true, watermark: '', watermarkClass: 'scFormObjectOddMultWm', maskChars: '(){}[].,;:-+/ '}"></span><?php } ?>
</td></tr><tr><td style="vertical-align: top; padding: 1px 0px 0px 0px"><table class="scFormFieldErrorTable" style="display: none" id="id_error_display_condicaopagamento<?php echo $sc_seq_vert; ?>_frame"><tr><td class="scFormFieldErrorMessage"><span id="id_error_display_condicaopagamento<?php echo $sc_seq_vert; ?>_text"></span></td></tr></table></td></tr></table> </TD>
   <?php }?>





   </tr>
<?php   
        if (isset($sCheckRead_cadunid))
       {
           $this->nmgp_cmp_readonly['cadunid'] = $sCheckRead_cadunid;
       }
       if ('display: none;' == $sStyleHidden_cadunid)
       {
           $this->nmgp_cmp_hidden['cadunid'] = 'off';
       }
       if (isset($sCheckRead_cotaitensid))
       {
           $this->nmgp_cmp_readonly['cotaitensid'] = $sCheckRead_cotaitensid;
       }
       if ('display: none;' == $sStyleHidden_cotaitensid)
       {
           $this->nmgp_cmp_hidden['cotaitensid'] = 'off';
       }
       if (isset($sCheckRead_statuscompraitem))
       {
           $this->nmgp_cmp_readonly['statuscompraitem'] = $sCheckRead_statuscompraitem;
       }
       if ('display: none;' == $sStyleHidden_statuscompraitem)
       {
           $this->nmgp_cmp_hidden['statuscompraitem'] = 'off';
       }
       if (isset($sCheckRead_statusmelhorpreco))
       {
           $this->nmgp_cmp_readonly['statusmelhorpreco'] = $sCheckRead_statusmelhorpreco;
       }
       if ('display: none;' == $sStyleHidden_statusmelhorpreco)
       {
           $this->nmgp_cmp_hidden['statusmelhorpreco'] = 'off';
       }
       if (isset($sCheckRead_valorunitario))
       {
           $this->nmgp_cmp_readonly['valorunitario'] = $sCheckRead_valorunitario;
       }
       if ('display: none;' == $sStyleHidden_valorunitario)
       {
           $this->nmgp_cmp_hidden['valorunitario'] = 'off';
       }
       if (isset($sCheckRead_condicaoentrega))
       {
           $this->nmgp_cmp_readonly['condicaoentrega'] = $sCheckRead_condicaoentrega;
       }
       if ('display: none;' == $sStyleHidden_condicaoentrega)
       {
           $this->nmgp_cmp_hidden['condicaoentrega'] = 'off';
       }
       if (isset($sCheckRead_condicaopagamento))
       {
           $this->nmgp_cmp_readonly['condicaopagamento'] = $sCheckRead_condicaopagamento;
       }
       if ('display: none;' == $sStyleHidden_condicaopagamento)
       {
           $this->nmgp_cmp_hidden['condicaopagamento'] = 'off';
       }

   }
   if ($Line_Add) 
   { 
       $this->New_Line = ob_get_contents();
       ob_end_clean();
       $this->nmgp_opcao = $guarda_nmgp_opcao;
       $this->form_vert_form_comprascotaresposta = $guarda_form_vert_form_comprascotaresposta;
   } 
   if ($Table_refresh) 
   { 
       $this->Table_refresh = ob_get_contents();
       ob_end_clean();
   } 
}

function Form_Fim() 
{
   global $sc_seq_vert, $opcao_botoes, $nm_url_saida; 
?>   
</TABLE></div><!-- bloco_f -->
 </div> 
<?php
$iContrVert = $this->Embutida_form ? $sc_seq_vert + 1 : $sc_seq_vert + 1;
if ($sc_seq_vert < $this->sc_max_reg)
{
    echo " <script type=\"text/javascript\">";
    echo "    bRefreshTable = true;";
    echo "</script>";
}
?>
<input type=hidden name="sc_contr_vert" value="<?php echo NM_encode_input($iContrVert); ?>">
<?php
    $sEmptyStyle = 0 == $sc_seq_vert ? '' : 'display: none;';
?>
</td></tr>
<tr id="sc-ui-empty-form" style="<?php echo $sEmptyStyle; ?>"><td class="scFormPageText" style="padding: 10px; text-align: center">
<?php echo $this->Ini->Nm_lang['lang_errm_empt'];
?>
</td></tr> 
<tr><td>
<?php
if ((!$this->Embutida_form || !$this->Embutida_call || $this->Grid_editavel || ($this->Embutida_call && 'on' == $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['embutida_liga_form_btn_nav'])) && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R")
{
?>
    <table style="border-collapse: collapse; border-width: 0px; width: 100%"><tr><td class="scFormToolbar" style="padding: 0px; spacing: 0px">
    <table style="border-collapse: collapse; border-width: 0px; width: 100%">
    <tr> 
     <td nowrap align="left" valign="middle" width="33%" class="scFormToolbarPadding"> 
<?php
}
if ((!$this->Embutida_form || !$this->Embutida_call || $this->Grid_editavel || ($this->Embutida_call && 'on' == $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['embutida_liga_form_btn_nav'])) && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R")
{
    $NM_btn = false;
      if ($opcao_botoes != "novo" && $this->nmgp_botoes['goto'] == "on")
      {
        $sCondStyle = '';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "birpara", " nm_navpage(document.F1.nmgp_rec_b.value, 'P');document.F1.nmgp_rec_b.value = ''", " nm_navpage(document.F1.nmgp_rec_b.value, 'P');document.F1.nmgp_rec_b.value = ''", "brec_b", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
?> 
   <input type="text" class="scFormToolbarInput" name="nmgp_rec_b" value="" style="width:25px;vertical-align: middle;"/> 
<?php 
      }
      if ($opcao_botoes != "novo" && $this->nmgp_botoes['qtline'] == "on")
      {
?> 
          <span class="<?php echo $this->css_css_toolbar_obj ?>" style="border: 0px;"><?php echo $this->Ini->Nm_lang['lang_btns_rows'] ?></span>
          <select class="scFormToolbarInput" name="nmgp_quant_linhas_b" onchange="document.F7.nmgp_max_line.value = this.value; document.F7.submit();"> 
<?php 
              $obj_sel = ($this->sc_max_reg == 10) ? " selected" : "";
?> 
           <option value="10" <?php echo $obj_sel ?>>10</option>
<?php 
              $obj_sel = ($this->sc_max_reg == 20) ? " selected" : "";
?> 
           <option value="20" <?php echo $obj_sel ?>>20</option>
<?php 
              $obj_sel = ($this->sc_max_reg == 50) ? " selected" : "";
?> 
           <option value="50" <?php echo $obj_sel ?>>50</option>
          </select>
<?php 
      }
?> 
     </td> 
     <td nowrap align="center" valign="middle" width="33%" class="scFormToolbarPadding"> 
<?php 
    if (($opcao_botoes != "novo") && ('total' != $this->form_paginacao)) {
        $sCondStyle = ($this->nmgp_botoes['first'] == "on") ? '' : 'display: none;';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "binicio", "nm_move ('inicio'); return false;", "nm_move ('inicio'); return false;", "sc_b_ini_b", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
        $NM_btn = true;
    }
    if (($opcao_botoes != "novo") && ('total' != $this->form_paginacao)) {
        $sCondStyle = ($this->nmgp_botoes['back'] == "on") ? '' : 'display: none;';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "bretorna", "nm_move ('retorna'); return false;", "nm_move ('retorna'); return false;", "sc_b_ret_b", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
        $NM_btn = true;
    }
if ($opcao_botoes != "novo" && $this->nmgp_botoes['navpage'] == "on")
{
?> 
     <span nowrap id="sc_b_navpage_b" class="scFormToolbarPadding"></span> 
<?php 
}
    if (($opcao_botoes != "novo") && ('total' != $this->form_paginacao)) {
        $sCondStyle = ($this->nmgp_botoes['forward'] == "on") ? '' : 'display: none;';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "bavanca", "nm_move ('avanca'); return false;", "nm_move ('avanca'); return false;", "sc_b_avc_b", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
        $NM_btn = true;
    }
    if (($opcao_botoes != "novo") && ('total' != $this->form_paginacao)) {
        $sCondStyle = ($this->nmgp_botoes['last'] == "on") ? '' : 'display: none;';
?>
       <?php echo nmButtonOutput($this->arr_buttons, "bfinal", "nm_move ('final'); return false;", "nm_move ('final'); return false;", "sc_b_fim_b", "", "", "" . $sCondStyle . "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
 
<?php
        $NM_btn = true;
    }
?> 
     </td> 
     <td nowrap align="right" valign="middle" width="33%" class="scFormToolbarPadding"> 
<?php 
if ($opcao_botoes != "novo" && $this->nmgp_botoes['summary'] == "on")
{
?> 
     <span nowrap id="sc_b_summary_b" class="scFormToolbarPadding"></span> 
<?php 
}
}
if ((!$this->Embutida_form || !$this->Embutida_call || $this->Grid_editavel || ($this->Embutida_call && 'on' == $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['embutida_liga_form_btn_nav'])) && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R")
{
?>
   </td></tr> 
   </table> 
   </td></tr></table> 
<?php
}
?>
<?php
if (!$NM_btn && isset($NM_ult_sep))
{
    echo "    <script language=\"javascript\">";
    echo "      document.getElementById('" .  $NM_ult_sep . "').style.display='none';";
    echo "    </script>";
}
unset($NM_ult_sep);
?>
<?php if ('novo' != $this->nmgp_opcao || $this->Embutida_form) { ?><script>nav_atualiza(Nav_permite_ret, Nav_permite_ava, 'b');</script><?php } ?>
<?php if (('novo' != $this->nmgp_opcao || $this->Embutida_form) && !$this->nmgp_form_empty && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F") { ?><script>summary_atualiza(<?php echo ($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['reg_start'] + 1). ", " . $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['reg_qtd'] . ", " . ($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['total'] + 1)?>);</script><?php } ?>
<?php if (('novo' != $this->nmgp_opcao || $this->Embutida_form) && !$this->nmgp_form_empty && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "R" && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['run_iframe'] != "F") { ?><script>navpage_atualiza('<?php echo $this->SC_nav_page ?>');</script><?php } ?>
</td></tr> 
</table> 

<div id="id_debug_window" style="display: none; position: absolute; left: 50px; top: 50px"><table class="scFormMessageTable">
<tr><td class="scFormMessageTitle"><?php echo nmButtonOutput($this->arr_buttons, "berrm_clse", "scAjaxHideDebug()", "scAjaxHideDebug()", "", "", "", "", "", "", "", $this->Ini->path_botoes, "", "", "", "");?>
&nbsp;&nbsp;Output</td></tr>
<tr><td class="scFormMessageMessage" style="padding: 0px; vertical-align: top"><div style="padding: 2px; height: 200px; width: 350px; overflow: auto" id="id_debug_text"></div></td></tr>
</table></div>
<script> 
 var iAjaxNewLine = <?php echo $sc_seq_vert; ?>;
 for (var iLine = 1; iLine <= iAjaxNewLine; iLine++) {
  scJQElementsAdd(iLine);
 }
</script> 
<div id="new_line_dummy" style="display: none">
</div>

</form> 
<script> 
<?php
  $nm_sc_blocos_da_pag = array(0);

  foreach ($this->Ini->nm_hidden_blocos as $bloco => $hidden)
  {
      if ($hidden == "off" && in_array($bloco, $nm_sc_blocos_da_pag))
      {
          echo "document.getElementById('hidden_bloco_" . $bloco . "').style.display = 'none';";
          if (isset($nm_sc_blocos_aba[$bloco]))
          {
               echo "document.getElementById('id_tabs_" . $nm_sc_blocos_aba[$bloco] . "_" . $bloco . "').style.display = 'none';";
          }
      }
  }
?>
</script> 
   </td></tr></table>
<script>
function updateHeaderFooter(sFldName, sFldValue)
{
  if (sFldValue[0] && sFldValue[0]["value"])
  {
    sFldValue = sFldValue[0]["value"];
  }
}
</script>
<?php
if (isset($_POST['master_nav']) && 'on' == $_POST['master_nav'])
{
?>
<script>parent.scAjaxDetailStatus("form_comprascotaresposta");</script>
<?php
}
?>
<?php
if (isset($this->NM_ajax_info['displayMsg']) && $this->NM_ajax_info['displayMsg'])
{
?>
<script type="text/javascript">
_scAjaxShowMessage(scMsgDefTitle, "<?php echo $this->NM_ajax_info['displayMsgTxt']; ?>", false, sc_ajaxMsgTime, false, "Ok", 0, 0, 0, 0, "", "", "", false, true);
</script>
<?php
}
?>
<?php
if ('' != $this->scFormFocusErrorName)
{
?>
<script>
scAjaxFocusError();
</script>
<?php
}
?>
<script>
bLigEditLookupCall = <?php if ($this->lig_edit_lookup_call) { ?>true<?php } else { ?>false<?php } ?>;
function scLigEditLookupCall()
{
<?php
if ($this->lig_edit_lookup && isset($_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['sc_modal']) && $_SESSION['sc_session'][$this->Ini->sc_page]['form_comprascotaresposta']['sc_modal'])
{
?>
  parent.<?php echo $this->lig_edit_lookup_cb; ?>(<?php echo $this->lig_edit_lookup_row; ?>);
<?php
}
elseif ($this->lig_edit_lookup)
{
?>
  opener.<?php echo $this->lig_edit_lookup_cb; ?>(<?php echo $this->lig_edit_lookup_row; ?>);
<?php
}
?>
}
if (bLigEditLookupCall)
{
  scLigEditLookupCall();
}
<?php
if (isset($this->redir_modal) && !empty($this->redir_modal))
{
    echo $this->redir_modal;
}
?>
</script>
</body> 
</html> 
<?php 
 } 
} 
?> 
