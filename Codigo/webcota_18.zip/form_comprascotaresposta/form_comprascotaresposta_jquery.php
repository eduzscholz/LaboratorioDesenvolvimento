
function scJQGeneralAdd() {
  $('input:text.sc-js-input').listen();
  $('input:password.sc-js-input').listen();
  $('textarea.sc-js-input').listen();

  $('#sc-ui-checkbox-statuscompraitem-control').click(function() { scJQCheckboxControl('statuscompraitem', '__ALL__', this); });

  $('#sc-ui-checkbox-statusmelhorpreco-control').click(function() { scJQCheckboxControl('statusmelhorpreco', '__ALL__', this); });

} // scJQGeneralAdd

function scFocusField(sField) {
  var $oField = $('#id_sc_field_' + sField);

  if (0 == $oField.length) {
    $oField = $('input[name=' + sField + ']');
  }

  if (0 == $oField.length && document.F1.elements[sField]) {
    $oField = $(document.F1.elements[sField]);
  }

  if (0 < $oField.length && 0 < $oField[0].offsetHeight && 0 < $oField[0].offsetWidth && !$oField[0].disabled) {
    $oField[0].focus();
  }
} // scFocusField

function scJQEventsAdd(iSeqRow) {
  $('#id_sc_field_cotaitensid' + iSeqRow).bind('blur', function() { sc_form_comprascotaresposta_cotaitensid_onblur(this, iSeqRow) })
                                         .bind('change', function() { sc_form_comprascotaresposta_cotaitensid_onchange(this, iSeqRow) })
                                         .bind('focus', function() { sc_form_comprascotaresposta_cotaitensid_onfocus(this, iSeqRow) });
  $('#id_sc_field_cadunid' + iSeqRow).bind('blur', function() { sc_form_comprascotaresposta_cadunid_onblur(this, iSeqRow) })
                                     .bind('change', function() { sc_form_comprascotaresposta_cadunid_onchange(this, iSeqRow) })
                                     .bind('focus', function() { sc_form_comprascotaresposta_cadunid_onfocus(this, iSeqRow) });
  $('#id_sc_field_valorunitario' + iSeqRow).bind('blur', function() { sc_form_comprascotaresposta_valorunitario_onblur(this, iSeqRow) })
                                           .bind('focus', function() { sc_form_comprascotaresposta_valorunitario_onfocus(this, iSeqRow) });
  $('#id_sc_field_condicaoentrega' + iSeqRow).bind('blur', function() { sc_form_comprascotaresposta_condicaoentrega_onblur(this, iSeqRow) })
                                             .bind('focus', function() { sc_form_comprascotaresposta_condicaoentrega_onfocus(this, iSeqRow) });
  $('#id_sc_field_condicaopagamento' + iSeqRow).bind('blur', function() { sc_form_comprascotaresposta_condicaopagamento_onblur(this, iSeqRow) })
                                               .bind('focus', function() { sc_form_comprascotaresposta_condicaopagamento_onfocus(this, iSeqRow) });
  $('#id_sc_field_statusmelhorpreco' + iSeqRow).bind('blur', function() { sc_form_comprascotaresposta_statusmelhorpreco_onblur(this, iSeqRow) })
                                               .bind('focus', function() { sc_form_comprascotaresposta_statusmelhorpreco_onfocus(this, iSeqRow) });
  $('#id_sc_field_statuscompraitem' + iSeqRow).bind('blur', function() { sc_form_comprascotaresposta_statuscompraitem_onblur(this, iSeqRow) })
                                              .bind('focus', function() { sc_form_comprascotaresposta_statuscompraitem_onfocus(this, iSeqRow) });
} // scJQEventsAdd

function sc_form_comprascotaresposta_cotaitensid_onblur(oThis, iSeqRow) {
  do_ajax_form_comprascotaresposta_validate_cotaitensid(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_cotaitensid_onchange(oThis, iSeqRow) {
  lookup_cotaitensid(iSeqRow);
}

function sc_form_comprascotaresposta_cotaitensid_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_cadunid_onblur(oThis, iSeqRow) {
  do_ajax_form_comprascotaresposta_validate_cadunid(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_cadunid_onchange(oThis, iSeqRow) {
  lookup_cadunid(iSeqRow);
}

function sc_form_comprascotaresposta_cadunid_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_valorunitario_onblur(oThis, iSeqRow) {
  do_ajax_form_comprascotaresposta_validate_valorunitario(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_valorunitario_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_condicaoentrega_onblur(oThis, iSeqRow) {
  do_ajax_form_comprascotaresposta_validate_condicaoentrega(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_condicaoentrega_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_condicaopagamento_onblur(oThis, iSeqRow) {
  do_ajax_form_comprascotaresposta_validate_condicaopagamento(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_condicaopagamento_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_statusmelhorpreco_onblur(oThis, iSeqRow) {
  do_ajax_form_comprascotaresposta_validate_statusmelhorpreco(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_statusmelhorpreco_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_statuscompraitem_onblur(oThis, iSeqRow) {
  do_ajax_form_comprascotaresposta_validate_statuscompraitem(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_form_comprascotaresposta_statuscompraitem_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

var sc_jq_calendar_value = {};

function scJQCalendarAdd(iSeqRow) {
  $("#id_sc_field_condicaoentrega" + iSeqRow).datepicker({
    beforeShow: function(input, inst) {
      var $oField = $(this),
          aParts  = $oField.val().split(" "),
          sTime   = "";
      sc_jq_calendar_value["#id_sc_field_condicaoentrega" + iSeqRow] = $oField.val();
    },
    onClose: function(dateText, inst) {
    },
    showWeek: true,
    numberOfMonths: 1,
    changeMonth: true,
    changeYear: true,
    yearRange: 'c-5:c+5',
    dayNames: ['<?php        echo html_entity_decode($this->Ini->Nm_lang['lang_days_sund']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_mond']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_tued']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_wend']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_thud']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_frid']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_satd']);        ?>'],
    dayNamesMin: ['<?php     echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_sund']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_mond']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_tued']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_wend']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_thud']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_frid']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_satd']); ?>'],
    monthNamesShort: ['<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_janu']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_febr']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_marc']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_apri']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_mayy']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_june']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_july']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_augu']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_sept']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_octo']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_nove']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_dece']); ?>'],
    weekHeader: "<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_days_sem']); ?>",
    firstDay: <?php echo $this->jqueryCalendarWeekInit("" . $_SESSION['scriptcase']['reg_conf']['date_week_ini'] . ""); ?>,
    dateFormat: "<?php echo $this->jqueryCalendarDtFormat("" . str_replace(array('/', 'aaaa', $_SESSION['scriptcase']['reg_conf']['date_sep']), array('', 'yyyy', ''), $this->field_config['condicaoentrega']['date_format']) . "", "" . $_SESSION['scriptcase']['reg_conf']['date_sep'] . ""); ?>",
    showOtherMonths: true,
    showOn: "button",
    buttonImage: "<?php echo $this->jqueryIconFile('calendar'); ?>",
    buttonImageOnly: true
  });

} // scJQCalendarAdd


function scJQElementsAdd(iLine) {
  scJQEventsAdd(iLine);
  scJQCalendarAdd(iLine);
} // scJQElementsAdd

function scJQCheckboxControl(sColumn, sSeqRow, oCheckbox) {
  var iSeqRow = '';

  if ('__ALL__' == sColumn || 'statuscompraitem' == sColumn) {
    iSeqRow = ('__REC__' == sSeqRow) ? $(oCheckbox).attr('alt') : '';
    scJQCheckboxControl_statuscompraitem(iSeqRow, oCheckbox.checked);
    if ('__REC__' == sSeqRow) {
      nm_check_insert(iSeqRow);
    }
    else {
      if ('__ALL__' == sColumn || 'statuscompraitem' == sColumn) {
         for (var i = 1; i <= iAjaxNewLine; i++) {
           nm_check_insert(i);
         }
      }
    }
    if ('__ALL__' == sColumn && '__ALL__' == sSeqRow) {
      var $oCheckbox = $(".sc-ui-checkbox-record-all");
      for (var i = 0; i < $oCheckbox.length; i++) {
        if (oCheckbox.checked != $oCheckbox[i].checked) {
          $oCheckbox[i].checked = oCheckbox.checked;
        }
      }
    }
  }

  if ('__ALL__' == sColumn || 'statusmelhorpreco' == sColumn) {
    iSeqRow = ('__REC__' == sSeqRow) ? $(oCheckbox).attr('alt') : '';
    scJQCheckboxControl_statusmelhorpreco(iSeqRow, oCheckbox.checked);
    if ('__REC__' == sSeqRow) {
      nm_check_insert(iSeqRow);
    }
    else {
      if ('__ALL__' == sColumn || 'statusmelhorpreco' == sColumn) {
         for (var i = 1; i <= iAjaxNewLine; i++) {
           nm_check_insert(i);
         }
      }
    }
    if ('__ALL__' == sColumn && '__ALL__' == sSeqRow) {
      var $oCheckbox = $(".sc-ui-checkbox-record-all");
      for (var i = 0; i < $oCheckbox.length; i++) {
        if (oCheckbox.checked != $oCheckbox[i].checked) {
          $oCheckbox[i].checked = oCheckbox.checked;
        }
      }
    }
  }

} // scJQCheckboxControl

function scJQCheckboxControl_statuscompraitem(iSeqRow, bChecked) {
  if ('__ALL__' == iSeqRow) {
    var $oCheckbox = $(".sc-ui-checkbox-statuscompraitem");
  }
  else {
    var $oCheckbox = $(".sc-ui-checkbox-statuscompraitem" + iSeqRow);
  }

  var bChanged = false;
  for (var i = 0; i < $oCheckbox.length; i++) {
    if (bChecked != $oCheckbox[i].checked && !$oCheckbox[i].disabled) {
      $oCheckbox[i].checked = bChecked;
      nm_check_insert(iSeqRow);
      bChanged = true;
    }
  }
} // scJQCheckboxControl_statuscompraitem

function scJQCheckboxControl_statusmelhorpreco(iSeqRow, bChecked) {
  if ('__ALL__' == iSeqRow) {
    var $oCheckbox = $(".sc-ui-checkbox-statusmelhorpreco");
  }
  else {
    var $oCheckbox = $(".sc-ui-checkbox-statusmelhorpreco" + iSeqRow);
  }

  var bChanged = false;
  for (var i = 0; i < $oCheckbox.length; i++) {
    if (bChecked != $oCheckbox[i].checked && !$oCheckbox[i].disabled) {
      $oCheckbox[i].checked = bChecked;
      nm_check_insert(iSeqRow);
      bChanged = true;
    }
  }
} // scJQCheckboxControl_statusmelhorpreco

