
function scJQGeneralAdd() {
  $('input:text.sc-js-input').listen();
  $('input:password.sc-js-input').listen();
  $('textarea.sc-js-input').listen();

  $('#sc-ui-checkbox-priv_access-control').click(function() { scJQCheckboxControl('priv_access', '__ALL__', this); });

  $('#sc-ui-checkbox-priv_insert-control').click(function() { scJQCheckboxControl('priv_insert', '__ALL__', this); });

  $('#sc-ui-checkbox-priv_delete-control').click(function() { scJQCheckboxControl('priv_delete', '__ALL__', this); });

  $('#sc-ui-checkbox-priv_update-control').click(function() { scJQCheckboxControl('priv_update', '__ALL__', this); });

  $('#sc-ui-checkbox-priv_export-control').click(function() { scJQCheckboxControl('priv_export', '__ALL__', this); });

  $('#sc-ui-checkbox-priv_print-control').click(function() { scJQCheckboxControl('priv_print', '__ALL__', this); });

  $('.sc-ui-checkbox-all-all').click(function() { scJQCheckboxControl('__ALL__', '__ALL__', this); });
  $('.sc-ui-checkbox-record-all').click(function() { scJQCheckboxControl('__ALL__', '__REC__', this); });

} // scJQGeneralAdd

function scFocusField(sField) {
  var $oField = $('#id_sc_field_' + sField);

  if (0 == $oField.length) {
    $oField = $('input[name=' + sField + ']');
  }

  if (0 == $oField.length && document.F1.elements[sField]) {
    $oField = $(document.F1.elements[sField]);
  }

  if (0 < $oField.length && 0 < $oField[0].offsetHeight && 0 < $oField[0].offsetWidth && !$oField[0].disabled) {
    $oField[0].focus();
  }
} // scFocusField

function scJQEventsAdd(iSeqRow) {
  $('#id_sc_field_app_name' + iSeqRow).bind('blur', function() { sc_sis_form_sec_users_apps_app_name_onblur(this, iSeqRow) })
                                      .bind('focus', function() { sc_sis_form_sec_users_apps_app_name_onfocus(this, iSeqRow) });
  $('#id_sc_field_priv_access' + iSeqRow).bind('blur', function() { sc_sis_form_sec_users_apps_priv_access_onblur(this, iSeqRow) })
                                         .bind('focus', function() { sc_sis_form_sec_users_apps_priv_access_onfocus(this, iSeqRow) });
  $('#id_sc_field_priv_insert' + iSeqRow).bind('blur', function() { sc_sis_form_sec_users_apps_priv_insert_onblur(this, iSeqRow) })
                                         .bind('focus', function() { sc_sis_form_sec_users_apps_priv_insert_onfocus(this, iSeqRow) });
  $('#id_sc_field_priv_delete' + iSeqRow).bind('blur', function() { sc_sis_form_sec_users_apps_priv_delete_onblur(this, iSeqRow) })
                                         .bind('focus', function() { sc_sis_form_sec_users_apps_priv_delete_onfocus(this, iSeqRow) });
  $('#id_sc_field_priv_update' + iSeqRow).bind('blur', function() { sc_sis_form_sec_users_apps_priv_update_onblur(this, iSeqRow) })
                                         .bind('focus', function() { sc_sis_form_sec_users_apps_priv_update_onfocus(this, iSeqRow) });
  $('#id_sc_field_priv_export' + iSeqRow).bind('blur', function() { sc_sis_form_sec_users_apps_priv_export_onblur(this, iSeqRow) })
                                         .bind('focus', function() { sc_sis_form_sec_users_apps_priv_export_onfocus(this, iSeqRow) });
  $('#id_sc_field_priv_print' + iSeqRow).bind('blur', function() { sc_sis_form_sec_users_apps_priv_print_onblur(this, iSeqRow) })
                                        .bind('focus', function() { sc_sis_form_sec_users_apps_priv_print_onfocus(this, iSeqRow) });
} // scJQEventsAdd

function sc_sis_form_sec_users_apps_app_name_onblur(oThis, iSeqRow) {
  do_ajax_sis_form_sec_users_apps_validate_app_name(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_app_name_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_access_onblur(oThis, iSeqRow) {
  do_ajax_sis_form_sec_users_apps_validate_priv_access(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_access_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_insert_onblur(oThis, iSeqRow) {
  do_ajax_sis_form_sec_users_apps_validate_priv_insert(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_insert_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_delete_onblur(oThis, iSeqRow) {
  do_ajax_sis_form_sec_users_apps_validate_priv_delete(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_delete_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_update_onblur(oThis, iSeqRow) {
  do_ajax_sis_form_sec_users_apps_validate_priv_update(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_update_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_export_onblur(oThis, iSeqRow) {
  do_ajax_sis_form_sec_users_apps_validate_priv_export(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_export_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_print_onblur(oThis, iSeqRow) {
  do_ajax_sis_form_sec_users_apps_validate_priv_print(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_sis_form_sec_users_apps_priv_print_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}


function scJQElementsAdd(iLine) {
  scJQEventsAdd(iLine);
} // scJQElementsAdd

function scJQCheckboxControl(sColumn, sSeqRow, oCheckbox) {
  var iSeqRow = '';

  if ('__ALL__' == sColumn || 'priv_access' == sColumn) {
    iSeqRow = ('__REC__' == sSeqRow) ? $(oCheckbox).attr('alt') : '';
    scJQCheckboxControl_priv_access(iSeqRow, oCheckbox.checked);
    if ('__REC__' == sSeqRow) {
      nm_check_insert(iSeqRow);
    }
    else {
      if ('__ALL__' == sColumn || 'priv_access' == sColumn) {
         for (var i = 1; i <= iAjaxNewLine; i++) {
           nm_check_insert(i);
         }
      }
    }
    if ('__ALL__' == sColumn && '__ALL__' == sSeqRow) {
      var $oCheckbox = $(".sc-ui-checkbox-record-all");
      for (var i = 0; i < $oCheckbox.length; i++) {
        if (oCheckbox.checked != $oCheckbox[i].checked) {
          $oCheckbox[i].checked = oCheckbox.checked;
        }
      }
    }
  }

  if ('__ALL__' == sColumn || 'priv_insert' == sColumn) {
    iSeqRow = ('__REC__' == sSeqRow) ? $(oCheckbox).attr('alt') : '';
    scJQCheckboxControl_priv_insert(iSeqRow, oCheckbox.checked);
    if ('__REC__' == sSeqRow) {
      nm_check_insert(iSeqRow);
    }
    else {
      if ('__ALL__' == sColumn || 'priv_insert' == sColumn) {
         for (var i = 1; i <= iAjaxNewLine; i++) {
           nm_check_insert(i);
         }
      }
    }
    if ('__ALL__' == sColumn && '__ALL__' == sSeqRow) {
      var $oCheckbox = $(".sc-ui-checkbox-record-all");
      for (var i = 0; i < $oCheckbox.length; i++) {
        if (oCheckbox.checked != $oCheckbox[i].checked) {
          $oCheckbox[i].checked = oCheckbox.checked;
        }
      }
    }
  }

  if ('__ALL__' == sColumn || 'priv_delete' == sColumn) {
    iSeqRow = ('__REC__' == sSeqRow) ? $(oCheckbox).attr('alt') : '';
    scJQCheckboxControl_priv_delete(iSeqRow, oCheckbox.checked);
    if ('__REC__' == sSeqRow) {
      nm_check_insert(iSeqRow);
    }
    else {
      if ('__ALL__' == sColumn || 'priv_delete' == sColumn) {
         for (var i = 1; i <= iAjaxNewLine; i++) {
           nm_check_insert(i);
         }
      }
    }
    if ('__ALL__' == sColumn && '__ALL__' == sSeqRow) {
      var $oCheckbox = $(".sc-ui-checkbox-record-all");
      for (var i = 0; i < $oCheckbox.length; i++) {
        if (oCheckbox.checked != $oCheckbox[i].checked) {
          $oCheckbox[i].checked = oCheckbox.checked;
        }
      }
    }
  }

  if ('__ALL__' == sColumn || 'priv_update' == sColumn) {
    iSeqRow = ('__REC__' == sSeqRow) ? $(oCheckbox).attr('alt') : '';
    scJQCheckboxControl_priv_update(iSeqRow, oCheckbox.checked);
    if ('__REC__' == sSeqRow) {
      nm_check_insert(iSeqRow);
    }
    else {
      if ('__ALL__' == sColumn || 'priv_update' == sColumn) {
         for (var i = 1; i <= iAjaxNewLine; i++) {
           nm_check_insert(i);
         }
      }
    }
    if ('__ALL__' == sColumn && '__ALL__' == sSeqRow) {
      var $oCheckbox = $(".sc-ui-checkbox-record-all");
      for (var i = 0; i < $oCheckbox.length; i++) {
        if (oCheckbox.checked != $oCheckbox[i].checked) {
          $oCheckbox[i].checked = oCheckbox.checked;
        }
      }
    }
  }

  if ('__ALL__' == sColumn || 'priv_export' == sColumn) {
    iSeqRow = ('__REC__' == sSeqRow) ? $(oCheckbox).attr('alt') : '';
    scJQCheckboxControl_priv_export(iSeqRow, oCheckbox.checked);
    if ('__REC__' == sSeqRow) {
      nm_check_insert(iSeqRow);
    }
    else {
      if ('__ALL__' == sColumn || 'priv_export' == sColumn) {
         for (var i = 1; i <= iAjaxNewLine; i++) {
           nm_check_insert(i);
         }
      }
    }
    if ('__ALL__' == sColumn && '__ALL__' == sSeqRow) {
      var $oCheckbox = $(".sc-ui-checkbox-record-all");
      for (var i = 0; i < $oCheckbox.length; i++) {
        if (oCheckbox.checked != $oCheckbox[i].checked) {
          $oCheckbox[i].checked = oCheckbox.checked;
        }
      }
    }
  }

  if ('__ALL__' == sColumn || 'priv_print' == sColumn) {
    iSeqRow = ('__REC__' == sSeqRow) ? $(oCheckbox).attr('alt') : '';
    scJQCheckboxControl_priv_print(iSeqRow, oCheckbox.checked);
    if ('__REC__' == sSeqRow) {
      nm_check_insert(iSeqRow);
    }
    else {
      if ('__ALL__' == sColumn || 'priv_print' == sColumn) {
         for (var i = 1; i <= iAjaxNewLine; i++) {
           nm_check_insert(i);
         }
      }
    }
    if ('__ALL__' == sColumn && '__ALL__' == sSeqRow) {
      var $oCheckbox = $(".sc-ui-checkbox-record-all");
      for (var i = 0; i < $oCheckbox.length; i++) {
        if (oCheckbox.checked != $oCheckbox[i].checked) {
          $oCheckbox[i].checked = oCheckbox.checked;
        }
      }
    }
  }

} // scJQCheckboxControl

function scJQCheckboxControl_priv_access(iSeqRow, bChecked) {
  if ('__ALL__' == iSeqRow) {
    var $oCheckbox = $(".sc-ui-checkbox-priv_access");
  }
  else {
    var $oCheckbox = $(".sc-ui-checkbox-priv_access" + iSeqRow);
  }

  var bChanged = false;
  for (var i = 0; i < $oCheckbox.length; i++) {
    if (bChecked != $oCheckbox[i].checked && !$oCheckbox[i].disabled) {
      $oCheckbox[i].checked = bChecked;
      nm_check_insert(iSeqRow);
      bChanged = true;
    }
  }
} // scJQCheckboxControl_priv_access

function scJQCheckboxControl_priv_insert(iSeqRow, bChecked) {
  if ('__ALL__' == iSeqRow) {
    var $oCheckbox = $(".sc-ui-checkbox-priv_insert");
  }
  else {
    var $oCheckbox = $(".sc-ui-checkbox-priv_insert" + iSeqRow);
  }

  var bChanged = false;
  for (var i = 0; i < $oCheckbox.length; i++) {
    if (bChecked != $oCheckbox[i].checked && !$oCheckbox[i].disabled) {
      $oCheckbox[i].checked = bChecked;
      nm_check_insert(iSeqRow);
      bChanged = true;
    }
  }
} // scJQCheckboxControl_priv_insert

function scJQCheckboxControl_priv_delete(iSeqRow, bChecked) {
  if ('__ALL__' == iSeqRow) {
    var $oCheckbox = $(".sc-ui-checkbox-priv_delete");
  }
  else {
    var $oCheckbox = $(".sc-ui-checkbox-priv_delete" + iSeqRow);
  }

  var bChanged = false;
  for (var i = 0; i < $oCheckbox.length; i++) {
    if (bChecked != $oCheckbox[i].checked && !$oCheckbox[i].disabled) {
      $oCheckbox[i].checked = bChecked;
      nm_check_insert(iSeqRow);
      bChanged = true;
    }
  }
} // scJQCheckboxControl_priv_delete

function scJQCheckboxControl_priv_update(iSeqRow, bChecked) {
  if ('__ALL__' == iSeqRow) {
    var $oCheckbox = $(".sc-ui-checkbox-priv_update");
  }
  else {
    var $oCheckbox = $(".sc-ui-checkbox-priv_update" + iSeqRow);
  }

  var bChanged = false;
  for (var i = 0; i < $oCheckbox.length; i++) {
    if (bChecked != $oCheckbox[i].checked && !$oCheckbox[i].disabled) {
      $oCheckbox[i].checked = bChecked;
      nm_check_insert(iSeqRow);
      bChanged = true;
    }
  }
} // scJQCheckboxControl_priv_update

function scJQCheckboxControl_priv_export(iSeqRow, bChecked) {
  if ('__ALL__' == iSeqRow) {
    var $oCheckbox = $(".sc-ui-checkbox-priv_export");
  }
  else {
    var $oCheckbox = $(".sc-ui-checkbox-priv_export" + iSeqRow);
  }

  var bChanged = false;
  for (var i = 0; i < $oCheckbox.length; i++) {
    if (bChecked != $oCheckbox[i].checked && !$oCheckbox[i].disabled) {
      $oCheckbox[i].checked = bChecked;
      nm_check_insert(iSeqRow);
      bChanged = true;
    }
  }
} // scJQCheckboxControl_priv_export

function scJQCheckboxControl_priv_print(iSeqRow, bChecked) {
  if ('__ALL__' == iSeqRow) {
    var $oCheckbox = $(".sc-ui-checkbox-priv_print");
  }
  else {
    var $oCheckbox = $(".sc-ui-checkbox-priv_print" + iSeqRow);
  }

  var bChanged = false;
  for (var i = 0; i < $oCheckbox.length; i++) {
    if (bChecked != $oCheckbox[i].checked && !$oCheckbox[i].disabled) {
      $oCheckbox[i].checked = bChecked;
      nm_check_insert(iSeqRow);
      bChanged = true;
    }
  }
} // scJQCheckboxControl_priv_print

