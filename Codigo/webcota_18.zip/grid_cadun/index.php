<?php 
  session_start();
?> 
<html> 
<head>
<title>grid_cadun</title> 
<META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
</head>
<body> 
<script> 
  window.location="grid_cadun.php?script_case_session=<?php echo session_id() ?>" ; 
</script> 
</body> 
</html> 
