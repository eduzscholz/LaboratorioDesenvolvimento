<?php
   include_once('sis_form_edit_users_session.php');
   if (!function_exists("NM_is_utf8"))
   {
       include_once("sis_form_edit_users_nmutf8.php");
   }
   session_start();

//----- 
   if (!empty($_POST))
   {
       foreach ($_POST as $nmgp_var => $nmgp_val)
       {
            $$nmgp_var = $nmgp_val;
       }
   }
   if (!empty($_GET))
   {
       foreach ($_GET as $nmgp_var => $nmgp_val)
       {
            $$nmgp_var = $nmgp_val;
       }
   }
   if (isset($_SESSION['session_sec_aplicacao']["webcota_____sis_form_edit_users"]))
   {
      unset($_SESSION['session_sec_aplicacao']["webcota_____sis_form_edit_users"]);
   }

   if (isset($_SESSION['session_sec_aplicacao']) && empty($_SESSION['session_sec_aplicacao']))
   {
      unset($_SESSION['session_sec_aplicacao']);
      unset($_SESSION['session_sec_usuario']);
   }
   unset($_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['sc_redir_atualiz']);
   unset($_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['sc_redir_insert']);
   $fecha_janela = false;
   if (isset($_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['sc_outra_jan']) && $_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['sc_outra_jan'])
   {
       $fecha_janela = true;
   }
   if ((isset($script_case_init) && isset($_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['opc_psq']) && $_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['opc_psq']) || $fecha_janela)
   {
       if (isset($script_case_init) && isset($_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['sc_modal']) && $_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['sc_modal'])
       {
           unset($_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['sc_modal']);
           if (!isset($_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['db_changed']) || $_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['db_changed'])
           {
               $saida_final = "if (typeof parent.nm_gp_move == 'function') {parent.nm_gp_move('edit');} self.parent.tb_remove()";
           }
           else
           {
               $saida_final = "self.parent.tb_remove()";
           }
       }
       else
       {
           if (!isset($_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['db_changed']) || $_SESSION['sc_session'][$script_case_init]['sis_form_edit_users']['db_changed'])
           {
              $saida_final = "if (opener && opener['nm_gp_move']) {opener.nm_gp_move('igual');} window.close()";
           }
           else
           {
              $saida_final = "window.close()";
           }
       }
      nm_limpa_arr_session();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
            "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">

<HTML>
<HEAD>
 <TITLE>sis_form_edit_users</TITLE>
 <META http-equiv="Content-Type" content="text/html; charset=<?php echo $_SESSION['scriptcase']['charset_html'] ?>" />
</HEAD>
<BODY>
<SCRIPT LANGUAGE="Javascript">
 <?php echo $saida_final; ?>;
</SCRIPT>
</BODY>
</HTML>
<?php
   }
   elseif (!isset($_SESSION['scriptcase']['sc_url_saida'][$script_case_init]) || empty($_SESSION['scriptcase']['sc_url_saida'][$script_case_init]))
   {
           nm_limpa_arr_session();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
            "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">

<HTML>
<HEAD>
 <TITLE>sis_form_edit_users</TITLE>
 <META http-equiv="Content-Type" content="text/html; charset=<?php echo $_SESSION['scriptcase']['charset_html'] ?>" />
</HEAD>
<BODY>
<SCRIPT LANGUAGE="Javascript">
  history.back();
</SCRIPT>
</BODY>
</HTML>
<?php
   }
   else
   {
       nm_limpa_arr_session();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
            "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">

<HTML>
<HEAD>
 <TITLE>sis_form_edit_users</TITLE>
 <META http-equiv="Content-Type" content="text/html; charset=<?php echo $_SESSION['scriptcase']['charset_html'] ?>" />
</HEAD>
<BODY>
<form name="fsai" method="post" action="<?php echo $_SESSION['scriptcase']['sc_url_saida'][$script_case_init]; ?>">
<input type=hidden name="script_case_init" value="<?php  echo NM_encode_input($script_case_init); ?>"> 
<input type=hidden name="script_case_session" value="<?php  echo NM_encode_input(session_id()); ?>"> 
</form>
<SCRIPT LANGUAGE="Javascript">
   nm_ver_saida = "<?php echo $_SESSION['scriptcase']['sc_url_saida'][$script_case_init]; ?>";
   nm_ver_saida = nm_ver_saida.toLowerCase();
   if (nm_ver_saida.substr(0, 4) != ".php" && (nm_ver_saida.substr(0, 7) == "http://" || nm_ver_saida.substr(0, 8) == "https://" || nm_ver_saida.substr(0, 3) == "../")) 
   { 
       window.location = ("<?php echo $_SESSION['scriptcase']['sc_url_saida'][$script_case_init]; ?>"); 
   } 
   else 
   { 
       document.fsai.submit();
   } 
</SCRIPT>
</BODY>
</HTML>
<?php
   }
   function nm_limpa_arr_session()
   {
      global $script_case_init;
      $achou = false;
      if (!isset($_SESSION['sc_session'][$script_case_init]) || !isset($script_case_init))
      {
          return;
      }
      foreach ($_SESSION['sc_session'][$script_case_init] as $nome_apl => $resto)
      {
          if ($nome_apl == 'sis_form_edit_users' || $achou)
          {
              unset($_SESSION['sc_session'][$script_case_init][$nome_apl]);
              $achou = true;
          }
      }
      if (empty($_SESSION['sc_session'][$script_case_init]))
      {
          unset($_SESSION['sc_session'][$script_case_init]);
      }
   }
?>
