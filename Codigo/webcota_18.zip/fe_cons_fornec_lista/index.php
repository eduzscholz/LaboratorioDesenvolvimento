<?php 
  session_start();
?> 
<html> 
<head>
<title>fe_cons_fornec_lista</title> 
<META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
</head>
<body> 
<script> 
  window.location="fe_cons_fornec_lista.php?script_case_session=<?php echo session_id() ?>" ; 
</script> 
</body> 
</html> 
