<?php
   Header('Location: fe_cons_fornec_lista.php');
?>
