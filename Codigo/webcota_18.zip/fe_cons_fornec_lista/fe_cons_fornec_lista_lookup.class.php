<?php
class fe_cons_fornec_lista_lookup
{
}
?>
