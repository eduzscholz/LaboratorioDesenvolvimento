<?php
   Header('Location: sis_grid_sec_apps.php');
?>
