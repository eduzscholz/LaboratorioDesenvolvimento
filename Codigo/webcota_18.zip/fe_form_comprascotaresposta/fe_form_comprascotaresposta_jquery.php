
function scJQGeneralAdd() {
  $('input:text.sc-js-input').listen();
  $('input:password.sc-js-input').listen();
  $('textarea.sc-js-input').listen();

} // scJQGeneralAdd

function scFocusField(sField) {
  var $oField = $('#id_sc_field_' + sField);

  if (0 == $oField.length) {
    $oField = $('input[name=' + sField + ']');
  }

  if (0 == $oField.length && document.F1.elements[sField]) {
    $oField = $(document.F1.elements[sField]);
  }

  if (0 < $oField.length && 0 < $oField[0].offsetHeight && 0 < $oField[0].offsetWidth && !$oField[0].disabled) {
    $oField[0].focus();
  }
} // scFocusField

function scJQEventsAdd(iSeqRow) {
  $('#id_sc_field_cotaitensid' + iSeqRow).bind('blur', function() { sc_fe_form_comprascotaresposta_cotaitensid_onblur(this, iSeqRow) })
                                         .bind('focus', function() { sc_fe_form_comprascotaresposta_cotaitensid_onfocus(this, iSeqRow) });
  $('#id_sc_field_valorunitario' + iSeqRow).bind('blur', function() { sc_fe_form_comprascotaresposta_valorunitario_onblur(this, iSeqRow) })
                                           .bind('focus', function() { sc_fe_form_comprascotaresposta_valorunitario_onfocus(this, iSeqRow) });
  $('#id_sc_field_condicaoentrega' + iSeqRow).bind('blur', function() { sc_fe_form_comprascotaresposta_condicaoentrega_onblur(this, iSeqRow) })
                                             .bind('focus', function() { sc_fe_form_comprascotaresposta_condicaoentrega_onfocus(this, iSeqRow) });
  $('#id_sc_field_condicaopagamento' + iSeqRow).bind('blur', function() { sc_fe_form_comprascotaresposta_condicaopagamento_onblur(this, iSeqRow) })
                                               .bind('focus', function() { sc_fe_form_comprascotaresposta_condicaopagamento_onfocus(this, iSeqRow) });
} // scJQEventsAdd

function sc_fe_form_comprascotaresposta_cotaitensid_onblur(oThis, iSeqRow) {
  do_ajax_fe_form_comprascotaresposta_validate_cotaitensid(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_fe_form_comprascotaresposta_cotaitensid_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_fe_form_comprascotaresposta_valorunitario_onblur(oThis, iSeqRow) {
  do_ajax_fe_form_comprascotaresposta_validate_valorunitario(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_fe_form_comprascotaresposta_valorunitario_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_fe_form_comprascotaresposta_condicaoentrega_onblur(oThis, iSeqRow) {
  do_ajax_fe_form_comprascotaresposta_validate_condicaoentrega(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_fe_form_comprascotaresposta_condicaoentrega_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

function sc_fe_form_comprascotaresposta_condicaopagamento_onblur(oThis, iSeqRow) {
  do_ajax_fe_form_comprascotaresposta_validate_condicaopagamento(iSeqRow);
  scCssBlur(oThis, iSeqRow);
}

function sc_fe_form_comprascotaresposta_condicaopagamento_onfocus(oThis, iSeqRow) {
  scCssFocus(oThis, iSeqRow);
}

var sc_jq_calendar_value = {};

function scJQCalendarAdd(iSeqRow) {
  $("#id_sc_field_condicaoentrega" + iSeqRow).datepicker({
    beforeShow: function(input, inst) {
      var $oField = $(this),
          aParts  = $oField.val().split(" "),
          sTime   = "";
      sc_jq_calendar_value["#id_sc_field_condicaoentrega" + iSeqRow] = $oField.val();
    },
    onClose: function(dateText, inst) {
    },
    showWeek: true,
    numberOfMonths: 1,
    changeMonth: true,
    changeYear: true,
    yearRange: 'c-5:c+5',
    dayNames: ['<?php        echo html_entity_decode($this->Ini->Nm_lang['lang_days_sund']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_mond']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_tued']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_wend']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_thud']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_frid']);        ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_days_satd']);        ?>'],
    dayNamesMin: ['<?php     echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_sund']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_mond']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_tued']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_wend']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_thud']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_frid']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_substr_days_satd']); ?>'],
    monthNamesShort: ['<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_janu']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_febr']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_marc']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_apri']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_mayy']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_june']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_july']);   ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_augu']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_sept']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_octo']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_nove']); ?>','<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_mnth_dece']); ?>'],
    weekHeader: "<?php echo html_entity_decode($this->Ini->Nm_lang['lang_shrt_days_sem']); ?>",
    firstDay: <?php echo $this->jqueryCalendarWeekInit("" . $_SESSION['scriptcase']['reg_conf']['date_week_ini'] . ""); ?>,
    dateFormat: "<?php echo $this->jqueryCalendarDtFormat("" . str_replace(array('/', 'aaaa', $_SESSION['scriptcase']['reg_conf']['date_sep']), array('', 'yyyy', ''), $this->field_config['condicaoentrega']['date_format']) . "", "" . $_SESSION['scriptcase']['reg_conf']['date_sep'] . ""); ?>",
    showOtherMonths: true,
    showOn: "button",
    buttonImage: "<?php echo $this->jqueryIconFile('calendar'); ?>",
    buttonImageOnly: true
  });

} // scJQCalendarAdd


function scJQElementsAdd(iLine) {
  scJQEventsAdd(iLine);
  scJQCalendarAdd(iLine);
} // scJQElementsAdd

