<?php 
  session_start();
?> 
<html> 
<head>
<title>sis_grid_sec_users_apps</title> 
<META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
</head>
<body> 
<script> 
  window.location="sis_grid_sec_users_apps.php?script_case_session=<?php echo session_id() ?>" ; 
</script> 
</body> 
</html> 
