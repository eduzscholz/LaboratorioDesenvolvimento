<?php
   Header('Location: be_cons_comprascotadoc.php');
?>
