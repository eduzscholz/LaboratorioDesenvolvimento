<?php
   Header('Location: sis_change_pswd.php');
?>
